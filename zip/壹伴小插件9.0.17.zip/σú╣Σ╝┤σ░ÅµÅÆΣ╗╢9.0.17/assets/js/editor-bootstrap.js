! function (e) {
  var t = {};

  function n(r) {
    if (t[r]) return t[r].exports;
    var i = t[r] = {
      i: r,
      l: !1,
      exports: {}
    };
    return e[r].call(i.exports, i, i.exports, n), i.l = !0, i.exports
  }
  n.m = e, n.c = t, n.d = function (e, t, r) {
    n.o(e, t) || Object.defineProperty(e, t, {
      enumerable: !0,
      get: r
    })
  }, n.r = function (e) {
    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
      value: "Module"
    }), Object.defineProperty(e, "__esModule", {
      value: !0
    })
  }, n.t = function (e, t) {
    if (1 & t && (e = n(e)), 8 & t) return e;
    if (4 & t && "object" == typeof e && e && e.__esModule) return e;
    var r = Object.create(null);
    if (n.r(r), Object.defineProperty(r, "default", {
      enumerable: !0,
      value: e
    }), 2 & t && "string" != typeof e)
      for (var i in e) n.d(r, i, function (t) {
        return e[t]
      }.bind(null, i));
    return r
  }, n.n = function (e) {
    var t = e && e.__esModule ? function () {
      return e.default
    } : function () {
      return e
    };
    return n.d(t, "a", t), t
  }, n.o = function (e, t) {
    return Object.prototype.hasOwnProperty.call(e, t)
  }, n.p = "/home/zhujunhong/workspace/mpa-extension/extension/assets/js", n(n.s = 332)
}({
  1: function (e, t, n) {
    "use strict";
    var r = this && this.__awaiter || function (e, t, n, r) {
      return new (n || (n = Promise))(function (i, o) {
        function a(e) {
          try {
            c(r.next(e))
          } catch (e) {
            o(e)
          }
        }

        function s(e) {
          try {
            c(r.throw(e))
          } catch (e) {
            o(e)
          }
        }

        function c(e) {
          e.done ? i(e.value) : new n(function (t) {
            t(e.value)
          }).then(a, s)
        }
        c((r = r.apply(e, t || [])).next())
      })
    },
      i = this && this.__generator || function (e, t) {
        var n, r, i, o, a = {
          label: 0,
          sent: function () {
            if (1 & i[0]) throw i[1];
            return i[1]
          },
          trys: [],
          ops: []
        };
        return o = {
          next: s(0),
          throw: s(1),
          return: s(2)
        }, "function" == typeof Symbol && (o[Symbol.iterator] = function () {
          return this
        }), o;

        function s(o) {
          return function (s) {
            return function (o) {
              if (n) throw new TypeError("Generator is already executing.");
              for (; a;) try {
                if (n = 1, r && (i = 2 & o[0] ? r.return : o[0] ? r.throw || ((i = r.return) && i.call(r), 0) : r.next) && !(i = i.call(r, o[1])).done) return i;
                switch (r = 0, i && (o = [2 & o[0], i.value]), o[0]) {
                  case 0:
                  case 1:
                    i = o;
                    break;
                  case 4:
                    return a.label++, {
                      value: o[1],
                      done: !1
                    };
                  case 5:
                    a.label++, r = o[1], o = [0];
                    continue;
                  case 7:
                    o = a.ops.pop(), a.trys.pop();
                    continue;
                  default:
                    if (!(i = (i = a.trys).length > 0 && i[i.length - 1]) && (6 === o[0] || 2 === o[0])) {
                      a = 0;
                      continue
                    }
                    if (3 === o[0] && (!i || o[1] > i[0] && o[1] < i[3])) {
                      a.label = o[1];
                      break
                    }
                    if (6 === o[0] && a.label < i[1]) {
                      a.label = i[1], i = o;
                      break
                    }
                    if (i && a.label < i[2]) {
                      a.label = i[2], a.ops.push(o);
                      break
                    }
                    i[2] && a.ops.pop(), a.trys.pop();
                    continue
                }
                o = t.call(e, a)
              } catch (e) {
                o = [6, e], r = 0
              } finally {
                  n = i = 0
                }
              if (5 & o[0]) throw o[1];
              return {
                value: o[0] ? o[1] : void 0,
                done: !0
              }
            }([o, s])
          }
        }
      };
    Object.defineProperty(t, "__esModule", {
      value: !0
    });
    var o, a = n(3),
      s = n(23);
    ! function (e) {
      e.KEYS = {
        ENTER: 13,
        BACKSPACE: 8
      }, e.getUrlArgs = function (t, n) {
        void 0 === t && (t = window.location.href), void 0 === n && (n = !1);
        var r = t.split("#")[0].split("?")[1];
        if (!r) return {};
        for (var i = {}, o = 0, a = r.split("&"); o < a.length; o++) {
          var s = a[o],
            c = s.indexOf("=");
          if (!(c < 0)) {
            var l = s.substr(0, c),
              u = s.substr(c + 1);
            if (!i[l]) {
              var d = void 0;
              try {
                d = decodeURIComponent(u)
              } catch (e) {
                d = u
              }
              i[l] = d
            }
          }
        }
        return n && (i = e.camelize(i)), i
      }, e.genApiUrl = function (t, n, r) {
        void 0 === r && (r = !1), n || (n = {}), r && (n = e.underlize(n));
        var i = [];
        for (var o in n) {
          var a = n[o];
          null !== a && i.push(o + "=" + a)
        }
        return 0 === i.length ? t : t + "?" + i.join("&")
      }, e.getHashArgs = function () {
        var t = window.location.hash;
        return t ? e.getUrlArgs("?" + t.slice(1)) : {}
      }, e.setHashArg = function (t, n) {
        var r = e.getHashArgs();
        if (null === n) {
          if (!r[t]) throw new Error("invalid " + t);
          delete r[t]
        } else r[t] = n;
        window.location.hash = e.genApiUrl("", r).slice(1)
      }, e.underlizeKey = function (e, t) {
        void 0 === t && (t = !1);
        for (var n = [], r = 0, i = e.toString().toLowerCase(); r < e.length;) e[r] === i[r] || t && 0 === r ? (n.push(e[r].toLocaleLowerCase()), r++) : (n.push("_"), n.push(i[r]), r++);
        return n.join("")
      }, e.underlize = function (t) {
        if (null == t) return null;
        if (t instanceof Array) return t.map(function (t) {
          return e.underlize(t)
        });
        if ("object" == typeof t) {
          var n = {};
          for (var r in t) {
            var i = t[r];
            n[e.underlizeKey(r)] = e.underlize(i)
          }
          return n
        }
        return t
      }, e.middlelizeKey = function (e, t) {
        void 0 === t && (t = !1);
        for (var n = [], r = 0, i = e.toString().toLowerCase(); r < e.length;) e[r] === i[r] || t && 0 === r ? (n.push(e[r].toLocaleLowerCase()), r++) : (n.push("-"), n.push(i[r]), r++);
        return n.join("")
      }, e.middlelize = function (t) {
        if (null == t) return null;
        if (t instanceof Array) return t.map(function (t) {
          return e.underlize(t)
        });
        if ("object" == typeof t) {
          var n = {};
          for (var r in t) {
            var i = t[r];
            n[e.middlelizeKey(r)] = e.middlelize(i)
          }
          return n
        }
        return t
      }, e.camelizeKey = function (e, t) {
        void 0 === t && (t = ["-", "_"]);
        for (var n = [], r = 0, i = new Set(t); r < e.length;) i.has(e[r]) ? (n.push(e[r + 1].toUpperCase()), r++) : n.push(e[r]), r++;
        return n.join("")
      }, e.camelize = function (t) {
        if (null == t) return null;
        if (t instanceof Array) return t.map(function (t) {
          return e.camelize(t)
        });
        if ("object" == typeof t) {
          var n = {};
          for (var r in t) {
            var i = t[r];
            n[e.camelizeKey(r)] = e.camelize(i)
          }
          return n
        }
        return t
      }, e.parseTime = function (t, n) {
        if (void 0 === n && (n = "Y年M月D日h点i分"), !t) return "";
        "number" == typeof t && (t = e.normalizeTime(t));
        for (var r = n.split(""), i = new Date(t), o = 0; o < r.length; o++) {
          switch (r[o]) {
            case "Y":
              r[o] = i.getFullYear() - 2e3;
              break;
            case "M":
              r[o] = i.getMonth() + 1;
              break;
            case "D":
              r[o] = i.getDate();
              break;
            case "y":
              r[o] = i.getFullYear();
              break;
            case "m":
              var a = i.getMonth() + 1;
              r[o] = a < 10 ? "0" + a : a.toString();
              break;
            case "d":
              var s = i.getDate();
              r[o] = s < 10 ? "0" + s : s.toString();
              break;
            case "w":
              switch (i.getDay()) {
                case 1:
                  r[o] = "一";
                  break;
                case 2:
                  r[o] = "二";
                  break;
                case 3:
                  r[o] = "三";
                  break;
                case 4:
                  r[o] = "四";
                  break;
                case 5:
                  r[o] = "五";
                  break;
                case 6:
                  r[o] = "六";
                  break;
                case 0:
                  r[o] = "日"
              }
              break;
            case "h":
              for (r[o] = i.getHours().toString(); r[o].length < 2;) r[o] = "0" + r[o];
              break;
            case "i":
              for (r[o] = i.getMinutes().toString(); r[o].length < 2;) r[o] = "0" + r[o];
              break;
            case "s":
              for (r[o] = i.getSeconds().toString(); r[o].length < 2;) r[o] = "0" + r[o];
              break;
            case "c":
              for (r[o] = i.getMilliseconds().toString(); r[o].length < 3;) r[o] = "0" + r[o]
          }
        }
        return r.join("")
      }, e.timeFromNow = function (t, n, r) {
        var i;
        void 0 === n && (n = !1), void 0 === r && (r = "Y-M-D h:i"), i = t instanceof Date ? t : new Date(e.normalizeTime(t));
        var o = (new Date).getTime(),
          a = o - i.getTime(),
          s = e.parseTime(i, "YMD"),
          c = e.parseTime(o, "YMD"),
          l = e.parseTime(o - 864e5, "YMD");
        return i.getFullYear() !== (new Date).getFullYear() ? n ? e.parseTime(i, r) : e.parseTime(i, "M月D日") : s !== c && s !== l ? n ? e.parseTime(i, r) : e.parseTime(i, "M月D日") : s === l ? "昨天" + e.parseTime(i, "h:i") : a > 36e5 ? Math.floor(a / 1e3 / 60 / 60) + "小时前" : a > 6e4 ? Math.floor(a / 1e3 / 60) + "分钟前" : "刚刚"
      }, e.normalizeTime = function (e, t) {
        return void 0 === t && (t = !1), e *= 1, t ? e > new Date("3000-01-01").getTime() / 1e3 && (e /= 1e3) : e < new Date("1971-01-01").getTime() && (e *= 1e3), e
      }, e.genSessionId = function () {
        return Date.now().toString(36) + parseInt(1e5 * Math.random() + "").toString(36)
      }, e.base64ToBlob = function (e, t, n) {
        void 0 === t && (t = ""), void 0 === n && (n = 512);
        for (var r = atob(e), i = [], o = 0; o < r.length;) {
          for (var a = r.slice(o, o + n), s = new Array(a.length), c = 0; c < a.length;) s[c] = a.charCodeAt(c), c++;
          i.push(new Uint8Array(s)), o += n
        }
        return new Blob(i, {
          type: t
        })
      }, e.getChromeVersion = function () {
        return parseInt(/Chrome\/([0-9.]+)/.exec(navigator.userAgent)[1])
      }, e.or = function (e, t) {
        return null != e ? e : t
      }, e.isHighDensity = function () {
        return window.devicePixelRatio > 1
      }, e.checkIfNeedUpdate = function (e, t) {
        var n = e.split("."),
          r = n[0],
          i = n[1],
          o = n[2],
          a = t.split("."),
          s = a[0],
          c = a[1],
          l = a[2],
          u = 1e6 * parseInt(r) + 1e3 * parseInt(i) + 1 * parseInt(o);
        return 1e6 * parseInt(s) + 1e3 * parseInt(c) + 1 * parseInt(l) > u
      }, e.genExtensionCallbackUrl = function (t, n) {
        var r = e.genApiUrl("/extension_callback/send_event", {
          data: encodeURIComponent(JSON.stringify({
            extension_id: t,
            event: n
          }))
        });
        return encodeURIComponent(r)
      }, e.getInlineScriptFromHtml = function (t, n) {
        var r = document.createElement("section");
        r.innerHTML = e.removeRefsFromHtml(t, !1);
        for (var i = [], o = r.querySelectorAll("script"), a = 0; a < o.length; a++) {
          var s = o[a];
          s.src || s.type && "text/javascript" !== s.type || (n ? n.test(s.innerHTML) && i.push(s.innerHTML) : i.push(s.innerHTML))
        }
        return i
      }, e.clone = function (t, n) {
        if (void 0 === n && (n = !1), t instanceof Array) {
          for (var r = [], i = 0, o = t; i < o.length; i++) {
            var a = o[i];
            n ? r.push(e.clone(a), n) : r.push(a)
          }
          return r
        }
        if ("object" == typeof t) {
          r = {};
          for (var s in t) r[s] = n ? e.clone(t[s], n) : t[s];
          return r
        }
        return t
      }, e.isObjectValueEqual = function e(t, n) {
        var r = Object.getOwnPropertyNames(t),
          i = Object.getOwnPropertyNames(n);
        if (r.length !== i.length) return !1;
        for (var o in t) {
          var a = t[o],
            s = n[o];
          if ("object" == typeof a) {
            if (!e(a, s)) return !1
          } else if (a !== s) return !1
        }
        return !0
      }, e.mapToList = function (e) {
        var t = [];
        for (var n in e) t.push(e[n]);
        return t
      }, e.listToMap = function (e, t) {
        for (var n = {}, r = 0, i = e; r < i.length; r++) {
          var o = i[r],
            a = o[t];
          a || console.error("Can't find key " + a + " in", o), n[a] = o
        }
        return n
      }, e.addUrlArgs = function (e, t) {
        var n = e.split("#"),
          r = n[0],
          i = n[1],
          o = [];
        for (var a in t) {
          var s = t[a];
          null != s && o.push(a + "=" + encodeURIComponent(s.toString()))
        }
        return r.indexOf("?") > -1 ? r += "&" + o.join("&") : r += "?" + o.join("&"), i ? r + "#" + i : r
      }, e.removeRefsFromHtml = function (e, t) {
        return void 0 === t && (t = !1), e = e.replace(/<img/g, "<noimg").replace(/<link /g, "<nolink "), t && (e = e.replace(/<(\/?)script/g, "<$1noscript")), e
      }, e.parseHtmlForData = function (t) {
        var n = document.createElement("div");
        return t = (t = (t = e.removeRefsFromHtml(t, !0)).replace(/<(\/?)body/g, "<$1bodydiv")).replace(/<(\/?)head/g, "<$1headdiv"), n.innerHTML = t, n
      }, e.getTimeByOffset = function (t, n) {
        void 0 === n && (n = "y-m-d");
        var r = Date.now() + 864e5 * t;
        return e.parseTime(r, n)
      }, e.retryUntilResolve = function (e, t) {
        var n, r = 0,
          i = new Promise(function (o, a) {
            ! function s() {
              console.log("call iter, " + r + "/" + t), (i = e()) instanceof Promise || (console.error("utils.retryUntilResolve only accept handler that return Promise instance"), a()), i.then(function (e) {
                o(e)
              }), i.catch(function (e) {
                return !0 === e ? a({
                  userAbort: !0
                }) : r < t ? (r += 1, s()) : n && !0 === n(e) ? (r += 0, s()) : void a({
                  userAbort: !1
                })
              })
            }()
          }),
          o = {
            handleMaxRetry: function (e) {
              return n = e, o
            },
            toPromise: function () {
              return i
            }
          };
        return o
      }, e.asyncDelay = function (e) {
        return new Promise(function (t) {
          setTimeout(function () {
            t()
          }, e)
        })
      }, e.forEachElement = function (e, t) {
        for (var n = e, r = 0; r < n.length; r++) {
          t(n[r], r)
        }
      }, e.unicodeToChar = function (e) {
        return e.replace(/\\u[\dA-F]{4}/gi, function (e) {
          return String.fromCharCode(parseInt(e.replace(/\\u/g, ""), 16))
        })
      }, e.addImageHIResSuffix = function (e) {
        var t = e.split("."),
          n = t[t.length - 1];
        return "png" !== n && "jpg" !== n && "gif" !== n || (t[t.length - 2] += a.IMG_HI_RES_SUFFIX), t.join(".")
      }, e.decodeHtmlEntities = function (e) {
        return $("<textarea/>").html(e).text()
      }, e.parseCurrency = function (t, n) {
        void 0 === n && (n = !1);
        var r = t / 100;
        return e.numberToFixed(r, 2, n)
      }, e.numberToFixed = function (e, t, n) {
        if (void 0 === n && (n = !1), isNaN(e)) return "NaN";
        var r = e.toString().split("."),
          i = r[0],
          o = r[1],
          a = void 0 === o ? "" : o,
          s = i + "." + a.slice(0, t);
        if (a.length < t && n)
          for (var c = 1; c <= t - a.length; c++) s += "0";
        return "." === s[s.length - 1] && (s = s.slice(0, -1)), s
      }, e.random = function (e, t, n) {
        void 0 === n && (n = !1);
        var r = Math.random() * (t - e);
        return n && (r = Math.round(r)), e + r
      }, e.onDOMReady = function (e) {
        "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", e) : e()
      }, e.merge = function (e, t) {
        var n = {};
        for (var r in e) n[r] = e[r];
        for (var r in t) n[r] = t[r];
        return n
      }, e.secureUrl = function (e) {
        return e.replace(/^http:/, "https:")
      }, e.throttle = function (e, t) {
        var n = null;
        return function () {
          var r = +new Date;
          (r - n > t || !n) && (e.apply(null, arguments), n = r)
        }
      }, e.debounce = function (e, t) {
        void 0 === t && (t = 300);
        var n = null;
        return function () {
          clearTimeout(n), n = setTimeout(function () {
            e()
          }, t)
        }
      }, e.genSyncTaskQueue = function (e, t) {
        var n = this;
        return new Promise(function (o, a) {
          var s = function () {
            var n, r;
            return i(this, function (i) {
              switch (i.label) {
                case 0:
                  n = 0, r = e.length, i.label = 1;
                case 1:
                  return n < r ? [4, t(e[n], n)] : [3, 4];
                case 2:
                  i.sent(), i.label = 3;
                case 3:
                  return n++, [3, 1];
                case 4:
                  return [2]
              }
            })
          }(),
            c = function () {
              return r(n, void 0, void 0, function () {
                var e, t, n, r;
                return i(this, function (i) {
                  switch (i.label) {
                    case 0:
                      if (e = s.next(), t = e.done, n = e.value, t) return [3, 5];
                      i.label = 1;
                    case 1:
                      return i.trys.push([1, 3, , 4]), [4, n];
                    case 2:
                      return i.sent(), [3, 4];
                    case 3:
                      return r = i.sent(), a(r), [3, 4];
                    case 4:
                      return c(), [3, 6];
                    case 5:
                      o(), i.label = 6;
                    case 6:
                      return [2]
                  }
                })
              })
            };
          c()
        })
      }, e.asyncGetTargetElementBySelector = function (t) {
        var n = function (e) {
          return document.querySelector(e)
        },
          r = n(t);
        return r ? Promise.resolve(r) : new Promise(function (r) {
          var i = new MutationObserver(function (o) {
            for (var a = 0, s = o; a < s.length; a++) {
              var c = s[a];
              if ("childList" !== c.type) return;
              var l = c.target;
              if (l && l.matches && l.matches(t) || l && l.querySelector(t)) return i.disconnect(), void r(n(t));
              e.forEachElement(c.addedNodes, function (e) {
                var o = e;
                return o && o.matches && o.matches(t) ? (i.disconnect(), r(n(t)), !0) : null
              })
            }
          });
          i.observe(document, {
            childList: !0,
            subtree: !0
          })
        })
      }, e.getChromeWebRequestResponseHeadersOptExtraInfoSpec = function () {
        var e = ["blocking", "responseHeaders"];
        try {
          chrome.webRequest.OnHeadersReceivedOptions.hasOwnProperty("EXTRA_HEADERS") && e.push("extraHeaders")
        } catch (e) { }
        return e
      }, e.getChromeWebRequestSendHeadersOptExtraInfoSpec = function () {
        var e = ["blocking", "requestHeaders"];
        try {
          chrome.webRequest.OnBeforeSendHeadersOptions.hasOwnProperty("EXTRA_HEADERS") && e.push("extraHeaders")
        } catch (e) { }
        return e
      }, e.eitherIs = function (e, t) {
        return function (n) {
          return n(e, t) || n(t, e)
        }
      }, e.convertInvalidMpAvatarToDefault = function (e) {
        return function (t) {
          return !t || t.includes("/misc/getheadimg") ? e + "/common/default-avatar.png" : t
        }
      }, e.createViewInstanceWithData = function (e, t) {
        void 0 === t && (t = {});
        var n = new e;
        return n.setData(t), n
      }, e.updateObjArrayByKey = function (e, t, n, r) {
        if (void 0 === r && (r = function (e, t) {
          return t
        }), !!n.find(function (e) {
          return !Object.prototype.hasOwnProperty.apply(t, [e])
        })) return e.slice();
        if (0 === n.length) return e.concat([t]);
        var i = e.find(function (e) {
          return n.reduce(function (n, r) {
            return n && e[r] === t[r]
          }, !0)
        });
        return i ? e.slice(0, e.indexOf(i)).concat([r(i, t)], e.slice(e.indexOf(i) + 1)) : e.concat([t])
      }, e.getBrowserInfo = function () {
        try {
          var e = window.navigator,
            t = e.userAgent,
            n = {},
            r = function (t, n) {
              var r = e.mimeTypes;
              for (var i in r)
                if (r[i][t] === n) return !0;
              return !1
            },
            i = {
              Trident: t.indexOf("Trident") > -1 || t.indexOf("NET CLR") > -1,
              Presto: t.indexOf("Presto") > -1,
              WebKit: t.indexOf("AppleWebKit") > -1,
              Gecko: t.indexOf("Gecko/") > -1,
              Safari: t.indexOf("Safari") > -1,
              Chrome: t.indexOf("Chrome") > -1 || t.indexOf("CriOS") > -1,
              IE: t.indexOf("MSIE") > -1 || t.indexOf("Trident") > -1,
              Edge: t.indexOf("Edge") > -1 || t.indexOf("Edg/") > -1,
              Firefox: t.indexOf("Firefox") > -1 || t.indexOf("FxiOS") > -1,
              "Firefox Focus": t.indexOf("Focus") > -1,
              Chromium: t.indexOf("Chromium") > -1,
              Opera: t.indexOf("Opera") > -1 || t.indexOf("OPR") > -1,
              Vivaldi: t.indexOf("Vivaldi") > -1,
              Yandex: t.indexOf("YaBrowser") > -1,
              Arora: t.indexOf("Arora") > -1,
              Lunascape: t.indexOf("Lunascape") > -1,
              QupZilla: t.indexOf("QupZilla") > -1,
              "Coc Coc": t.indexOf("coc_coc_browser") > -1,
              Kindle: t.indexOf("Kindle") > -1 || t.indexOf("Silk/") > -1,
              Iceweasel: t.indexOf("Iceweasel") > -1,
              Konqueror: t.indexOf("Konqueror") > -1,
              Iceape: t.indexOf("Iceape") > -1,
              SeaMonkey: t.indexOf("SeaMonkey") > -1,
              Epiphany: t.indexOf("Epiphany") > -1,
              360: t.indexOf("QihooBrowser") > -1 || t.indexOf("QHBrowser") > -1,
              "360EE": t.indexOf("360EE") > -1,
              "360SE": t.indexOf("360SE") > -1,
              UC: t.indexOf("UC") > -1 || t.indexOf(" UBrowser") > -1,
              QQBrowser: t.indexOf("QQBrowser") > -1,
              QQ: t.indexOf("QQ/") > -1,
              Baidu: t.indexOf("Baidu") > -1 || t.indexOf("BIDUBrowser") > -1 || t.indexOf("baiduboxapp") > -1,
              Maxthon: t.indexOf("Maxthon") > -1,
              Sogou: t.indexOf("MetaSr") > -1 || t.indexOf("Sogou") > -1,
              LBBROWSER: t.indexOf("LBBROWSER") > -1,
              "2345Explorer": t.indexOf("2345Explorer") > -1 || t.indexOf("Mb2345Browser") > -1,
              "115Browser": t.indexOf("115Browser") > -1,
              TheWorld: t.indexOf("TheWorld") > -1,
              XiaoMi: t.indexOf("MiuiBrowser") > -1,
              Quark: t.indexOf("Quark") > -1,
              Qiyu: t.indexOf("Qiyu") > -1,
              Wechat: t.indexOf("MicroMessenger") > -1,
              Taobao: t.indexOf("AliApp(TB") > -1,
              Alipay: t.indexOf("AliApp(AP") > -1,
              Weibo: t.indexOf("Weibo") > -1,
              Douban: t.indexOf("com.douban.frodo") > -1,
              Suning: t.indexOf("SNEBUY-APP") > -1,
              iQiYi: t.indexOf("IqiyiApp") > -1,
              DingTalk: t.indexOf("DingTalk") > -1,
              Huawei: t.indexOf("HuaweiBrowser") > -1 || t.indexOf("HUAWEI") > -1,
              Windows: t.indexOf("Windows") > -1,
              Linux: t.indexOf("Linux") > -1 || t.indexOf("X11") > -1,
              "Mac OS": t.indexOf("Macintosh") > -1,
              Android: t.indexOf("Android") > -1 || t.indexOf("Adr") > -1,
              Ubuntu: t.indexOf("Ubuntu") > -1,
              FreeBSD: t.indexOf("FreeBSD") > -1,
              Debian: t.indexOf("Debian") > -1,
              "Windows Phone": t.indexOf("IEMobile") > -1 || t.indexOf("Windows Phone") > -1,
              BlackBerry: t.indexOf("BlackBerry") > -1 || t.indexOf("RIM") > -1,
              MeeGo: t.indexOf("MeeGo") > -1,
              Symbian: t.indexOf("Symbian") > -1,
              iOS: t.indexOf("like Mac OS X") > -1,
              "Chrome OS": t.indexOf("CrOS") > -1,
              WebOS: t.indexOf("hpwOS") > -1,
              Mobile: t.indexOf("Mobi") > -1 || t.indexOf("iPh") > -1 || t.indexOf("480") > -1,
              Tablet: t.indexOf("Tablet") > -1 || t.indexOf("Pad") > -1 || t.indexOf("Nexus 7") > -1
            },
            o = !1;
          if (window.chrome) {
            var a = parseFloat(t.replace(/^.*Chrome\/([\d]+).*$/, "$1"));
            window.chrome.adblock2345 || window.chrome.common2345 ? i["2345Explorer"] = !0 : r("type", "application/360softmgrplugin") || r("type", "application/mozilla-npqihooquicklogin") ? o = !0 : a > 36 && window.showModalDialog ? o = !0 : a > 45 && !(o = r("type", "application/vnd.chromium.remoting-viewer")) && a >= 69 && (o = r("type", "application/hwepass2001.installepass2001") || r("type", "application/asx"))
          }
          if (i.Mobile ? i.Mobile = !(t.indexOf("iPad") > -1) : o && (r("type", "application/gameplugin") ? i["360SE"] = !0 : e && void 0 !== e.connection && void 0 === e.connection.saveData ? i["360SE"] = !0 : i["360EE"] = !0), i.IE || i.Edge) switch (window.screenTop - window.screenY) {
            case 71:
            case 99:
            case 102:
              i["360EE"] = !0;
              break;
            case 75:
            case 105:
            case 104:
              i["360SE"] = !0
          }
          i.Baidu && i.Opera ? i.Baidu = !1 : i.iOS && (i.Safari = !0);
          var s = {
            engine: ["WebKit", "Trident", "Gecko", "Presto"],
            browser: ["Safari", "Chrome", "Edge", "IE", "Firefox", "Firefox Focus", "Chromium", "Opera", "Vivaldi", "Yandex", "Arora", "Lunascape", "QupZilla", "Coc Coc", "Kindle", "Iceweasel", "Konqueror", "Iceape", "SeaMonkey", "Epiphany", "XiaoMi", "Huawei", "360", "360SE", "360EE", "UC", "QQBrowser", "QQ", "Baidu", "Maxthon", "Sogou", "LBBROWSER", "2345Explorer", "115Browser", "TheWorld", "Quark", "Qiyu", "Wechat", "Taobao", "Alipay", "Weibo", "Douban", "Suning", "iQiYi", "DingTalk"],
            os: ["Windows", "Linux", "Mac OS", "Android", "Ubuntu", "FreeBSD", "Debian", "iOS", "Windows Phone", "BlackBerry", "MeeGo", "Symbian", "Chrome OS", "WebOS"],
            device: ["Mobile", "Tablet"]
          };
          for (var c in n.device = "PC", n.language = ((f = (e.browserLanguage || e.language).split("-"))[1] && (f[1] = f[1].toUpperCase()), f.join("_")), s)
            for (var l = 0; l < s[c].length; l++) {
              var u = s[c][l];
              i[u] && (n[c] = u)
            }
          var d = {
            Windows: function () {
              var e = t.replace(/^Mozilla\/\d.0 \(Windows NT ([\d.]+);.*$/, "$1");
              return {
                10: "10",
                6.4: "10",
                6.3: "8.1",
                6.2: "8",
                6.1: "7",
                "6.0": "Vista",
                5.2: "XP",
                5.1: "XP",
                "5.0": "2000"
              }[e] || e
            },
            Android: function () {
              return t.replace(/^.*Android ([\d.]+);.*$/, "$1")
            },
            iOS: function () {
              return t.replace(/^.*OS ([\d_]+) like.*$/, "$1").replace(/_/g, ".")
            },
            Debian: function () {
              return t.replace(/^.*Debian\/([\d.]+).*$/, "$1")
            },
            "Windows Phone": function () {
              return t.replace(/^.*Windows Phone( OS)? ([\d.]+);.*$/, "$2")
            },
            "Mac OS": function () {
              return t.replace(/^.*Mac OS X ([\d_]+).*$/, "$1").replace(/_/g, ".")
            },
            WebOS: function () {
              return t.replace(/^.*hpwOS\/([\d.]+);.*$/, "$1")
            }
          };
          n.osVersion = "", d[n.os] && (n.osVersion = d[n.os](), n.osVersion === t && (n.osVersion = ""));
          var p = {
            Safari: function () {
              return t.replace(/^.*Version\/([\d.]+).*$/, "$1")
            },
            Chrome: function () {
              return t.replace(/^.*Chrome\/([\d.]+).*$/, "$1").replace(/^.*CriOS\/([\d.]+).*$/, "$1")
            },
            IE: function () {
              return t.replace(/^.*MSIE ([\d.]+).*$/, "$1").replace(/^.*rv:([\d.]+).*$/, "$1")
            },
            Edge: function () {
              return t.replace(/^.*Edge\/([\d.]+).*$/, "$1").replace(/^.*Edg\/([\d.]+).*$/, "$1")
            },
            Firefox: function () {
              return t.replace(/^.*Firefox\/([\d.]+).*$/, "$1").replace(/^.*FxiOS\/([\d.]+).*$/, "$1")
            },
            "Firefox Focus": function () {
              return t.replace(/^.*Focus\/([\d.]+).*$/, "$1")
            },
            Chromium: function () {
              return t.replace(/^.*Chromium\/([\d.]+).*$/, "$1")
            },
            Opera: function () {
              return t.replace(/^.*Opera\/([\d.]+).*$/, "$1").replace(/^.*OPR\/([\d.]+).*$/, "$1")
            },
            Vivaldi: function () {
              return t.replace(/^.*Vivaldi\/([\d.]+).*$/, "$1")
            },
            Yandex: function () {
              return t.replace(/^.*YaBrowser\/([\d.]+).*$/, "$1")
            },
            Arora: function () {
              return t.replace(/^.*Arora\/([\d.]+).*$/, "$1")
            },
            Lunascape: function () {
              return t.replace(/^.*Lunascape[\/\s]([\d.]+).*$/, "$1")
            },
            QupZilla: function () {
              return t.replace(/^.*QupZilla[\/\s]([\d.]+).*$/, "$1")
            },
            "Coc Coc": function () {
              return t.replace(/^.*coc_coc_browser\/([\d.]+).*$/, "$1")
            },
            Kindle: function () {
              return t.replace(/^.*Version\/([\d.]+).*$/, "$1")
            },
            Iceweasel: function () {
              return t.replace(/^.*Iceweasel\/([\d.]+).*$/, "$1")
            },
            Konqueror: function () {
              return t.replace(/^.*Konqueror\/([\d.]+).*$/, "$1")
            },
            Iceape: function () {
              return t.replace(/^.*Iceape\/([\d.]+).*$/, "$1")
            },
            SeaMonkey: function () {
              return t.replace(/^.*SeaMonkey\/([\d.]+).*$/, "$1")
            },
            Epiphany: function () {
              return t.replace(/^.*Epiphany\/([\d.]+).*$/, "$1")
            },
            360: function () {
              return t.replace(/^.*QihooBrowser\/([\d.]+).*$/, "$1")
            },
            "360SE": function () {
              return {
                78: "12.1",
                69: "11.1",
                63: "10.0",
                55: "9.1",
                45: "8.1",
                42: "8.0",
                31: "7.0",
                21: "6.3"
              }[t.replace(/^.*Chrome\/([\d]+).*$/, "$1")] || ""
            },
            "360EE": function () {
              return {
                78: "12.0",
                69: "11.0",
                63: "9.5",
                55: "9.0",
                50: "8.7",
                30: "7.5"
              }[t.replace(/^.*Chrome\/([\d]+).*$/, "$1")] || ""
            },
            Maxthon: function () {
              return t.replace(/^.*Maxthon\/([\d.]+).*$/, "$1")
            },
            QQBrowser: function () {
              return t.replace(/^.*QQBrowser\/([\d.]+).*$/, "$1")
            },
            QQ: function () {
              return t.replace(/^.*QQ\/([\d.]+).*$/, "$1")
            },
            Baidu: function () {
              return t.replace(/^.*BIDUBrowser[\s\/]([\d.]+).*$/, "$1").replace(/^.*baiduboxapp\/([\d.]+).*$/, "$1")
            },
            UC: function () {
              return t.replace(/^.*UC?Browser\/([\d.]+).*$/, "$1")
            },
            Sogou: function () {
              return t.replace(/^.*SE ([\d.X]+).*$/, "$1").replace(/^.*SogouMobileBrowser\/([\d.]+).*$/, "$1")
            },
            LBBROWSER: function () {
              return {
                57: "6.5",
                49: "6.0",
                46: "5.9",
                42: "5.3",
                39: "5.2",
                34: "5.0",
                29: "4.5",
                21: "4.0"
              }[e.userAgent.replace(/^.*Chrome\/([\d]+).*$/, "$1")] || ""
            },
            "2345Explorer": function () {
              return {
                69: "10.0",
                55: "9.9"
              }[e.userAgent.replace(/^.*Chrome\/([\d]+).*$/, "$1")] || t.replace(/^.*2345Explorer\/([\d.]+).*$/, "$1").replace(/^.*Mb2345Browser\/([\d.]+).*$/, "$1")
            },
            "115Browser": function () {
              return t.replace(/^.*115Browser\/([\d.]+).*$/, "$1")
            },
            TheWorld: function () {
              return t.replace(/^.*TheWorld ([\d.]+).*$/, "$1")
            },
            XiaoMi: function () {
              return t.replace(/^.*MiuiBrowser\/([\d.]+).*$/, "$1")
            },
            Quark: function () {
              return t.replace(/^.*Quark\/([\d.]+).*$/, "$1")
            },
            Qiyu: function () {
              return t.replace(/^.*Qiyu\/([\d.]+).*$/, "$1")
            },
            Wechat: function () {
              return t.replace(/^.*MicroMessenger\/([\d.]+).*$/, "$1")
            },
            Taobao: function () {
              return t.replace(/^.*AliApp\(TB\/([\d.]+).*$/, "$1")
            },
            Alipay: function () {
              return t.replace(/^.*AliApp\(AP\/([\d.]+).*$/, "$1")
            },
            Weibo: function () {
              return t.replace(/^.*weibo__([\d.]+).*$/, "$1")
            },
            Douban: function () {
              return t.replace(/^.*com.douban.frodo\/([\d.]+).*$/, "$1")
            },
            Suning: function () {
              return t.replace(/^.*SNEBUY-APP([\d.]+).*$/, "$1")
            },
            iQiYi: function () {
              return t.replace(/^.*IqiyiVersion\/([\d.]+).*$/, "$1")
            },
            DingTalk: function () {
              return t.replace(/^.*DingTalk\/([\d.]+).*$/, "$1")
            },
            Huawei: function () {
              return t.replace(/^.*Version\/([\d.]+).*$/, "$1").replace(/^.*HuaweiBrowser\/([\d.]+).*$/, "$1")
            }
          };
          if (n.version = "", p[n.browser] && (n.version = p[n.browser](), n.version === t && (n.version = "")), "Edge" === n.browser ? n.version > "75" ? n.engine = "Blink" : n.engine = "EdgeHTML" : i.Chrome && "WebKit" === n.engine && parseInt(p.Chrome()) > 27 ? n.engine = "Blink" : "Opera" === n.browser && parseInt(n.version) > 12 ? n.engine = "Blink" : "Yandex" === n.browser && (n.engine = "Blink"), "Mac OS" === n.os) "69" === (a = t.replace(/^.*Chrome\/([\d]+).*$/, "$1")) && (n.browser = "360EE");
          return n
        } catch (e) {
          return console.error("browser info parse error", e), {
            browser: "Chrome",
            engine: "WebKit",
            os: "Windows",
            device: "PC",
            version: "-",
            osVersion: "-",
            language: "-"
          }
        }
        var f
      }, e.sortUrl = function (e) {
        var t = e.replace(/http:\/\/mmbiz.qpic.cn\//g, "https://mmbiz.qpic.cn/");
        return t = t.replace(/url(\([^\(]*\))/g, function (e) {
          return e = e.replace(/&quot;/g, "")
        })
      }, e.proxyImgUrlOfHtml = function (r, i) {
        void 0 === i && (i = !1), r || (r = "");
        var o = i ? n : t,
          s = function (e) {
            var t = !1;
            return a.BASE64_IMG_REG.test(e) && (t = !0), t || o.some(function (n) {
              return e.indexOf(n) > -1 && (t = !0, !0)
            }), t || a.PROXIED_IMG_URL_REG.test(e) || (e = e.replace("http", "https://" + a.IMG_PROXY_HOST + "/img_proxy?src=http")), e
          };
        return r = (r = r.replace(/url(\([^\(]*\))/g, function (e) {
          return s(e)
        })).replace(/src=(\"[^\"]*\")/g, function (e) {
          return s(e)
        }), i && (r = e.restoreProxiedWxImgOfHtml(r)), r
      }, e.restoreProxiedWxImgOfHtml = function (e) {
        return e = e.replace(a.PROXIED_WX_IMG_URL_REG, "https://" + a.WX_IMG_HOST)
      }, e.templateVwToPx = function (e, t) {
        var n = e.match(/\d+(\.\d+)?vw[\s|;|,]/gi);
        return n && n.forEach(function (n) {
          var r, i, o;
          e = e.replace(n, (r = n, i = parseFloat(r.replace("vw", "")), o = r.indexOf(";") > -1 ? ";" : r.indexOf(",") > -1 ? "," : " ", (i * t / 100).toFixed(0) + "px" + o))
        }), e
      }, e.blackTechChangeHeight = function (e, t) {
        var n = e.match(/width="\d+(\.\d+)?px"/gi);
        if (n && n[0]) {
          var r = parseFloat(n[0].slice(7));
          n.forEach(function (n, r) {
            0 === r && (e = e.replace(n, 'width="' + t + 'px"'))
          });
          var i = e.match(/height="\d+(\.\d+)?px"/gi);
          if (i) {
            i.forEach(function (n, i) {
              if (0 === i) {
                var o = parseFloat(n.slice(8));
                e = e.replace(n, function (e) {
                  return 'height="' + e * t / r + 'px"'
                }(o))
              }
            })
          }
        }
        return e
      }, e.compose = s.compose, e.judgeUserIsForeverVip = function (e) {
        var t = e.vipExpireAt,
          n = e.vipVersion,
          r = new Date(2100, 0, 1).getTime() / 1e3,
          i = !1;
        return "vip2" === n && t >= r && (i = !0), i
      };
      var t = [location.host, "notecdn.yiban.io", "mcdn.yiban.io", "cdn.yiban.io"],
        n = t.concat(["mmbiz.qpic.cn"]);
      e.proxyImgUrl = function (e, r) {
        void 0 === r && (r = !1), e || (e = "");
        var i = !1;
        return a.BASE64_IMG_REG.test(e) && (i = !0), i || (r ? n : t).some(function (t) {
          return e.indexOf(t) > -1 && (i = !0, !0)
        }), i || a.PROXIED_IMG_URL_REG.test(e) || (e = "https://" + a.IMG_PROXY_HOST + "/img_proxy?src=" + e), e
      }, e.parseTextForMassSendTextMsg = function (t) {
        var n = document.createElement("div");
        n.innerHTML = t.replace(/&nbsp;/g, "");
        var r = [],
          i = function (e) {
            var t = e.nextSibling;
            t && "DIV" !== t.nodeName || r.push("\r\n")
          },
          o = function (t) {
            if ("A" === t.nodeName) {
              var n = t.childNodes;
              if (n.length > 0) {
                var a = function (e) {
                  "IMG" === e.firstChild.nodeName && (r.push(e.firstChild.dataset.emotionCode), e.firstChild.remove()), "IMG" === e.lastChild.nodeName && (r.push(e.lastChild.dataset.emotionCode), e.lastChild.remove())
                };
                n.length > 1 ? n.forEach(function (e) {
                  e.hasChildNodes() && a(e)
                }) : "P" === n[0].nodeName && a(n[0]);
                var s = t,
                  c = s.getAttribute("data-miniprogram-appid"),
                  l = s.getAttribute("data-miniprogram-path"),
                  u = '<a href="' + s.href + '"  ' + (c ? 'data-miniprogram-appid="' + c + '"' : "") + " " + (l ? 'data-miniprogram-path="' + l + '"' : "") + ">" + s.innerText.trim() + "</a> ";
                r.push(u), i(t)
              }
            } else "粉丝昵称" === t.nodeValue && t.parentElement.hasAttribute("data-nick-name") ? (r.push("&nbsp;{fans.nickname}&nbsp;"), i(t.parentElement)) : 3 === t.nodeType ? t.nodeValue.trim() && (r.push(e.decodeHtmlEntities(t.nodeValue)), t.nextSibling || "DIV" !== t.parentElement.nodeName && t.parentElement.nextSibling && "DIV" !== t.parentElement.nextSibling.nodeName || i(t)) : "IMG" === t.nodeName ? (r.push(t.dataset.emotionCode), i(t)) : "BR" === t.nodeName ? r.push("\r\n") : t.hasChildNodes() && Array.from(t.childNodes).forEach(function (e) {
              o(e)
            })
          };
        return Array.from(n.childNodes).forEach(function (e) {
          o(e)
        }), r.join("")
      }, e.parseTextWithFanNicknames = function (e) {
        var t = document.createElement("div");
        t.innerHTML = e;
        var n = [],
          r = function (e) {
            "粉丝昵称" === e.nodeValue && e.parentElement.hasAttribute("data-nick-name") ? n.push("&nbsp;{fans.nickname}&nbsp;") : e.hasChildNodes() ? Array.from(e.childNodes).forEach(function (e) {
              r(e)
            }) : 3 === e.nodeType && n.push(e.nodeValue)
          };
        return Array.from(t.childNodes).forEach(function (e) {
          r(e)
        }), n.join("")
      }, e.awaitWxIndexPageDomLoaded = function () {
        return r(this, void 0, Promise, function () {
          var t, n;
          return i(this, function (r) {
            switch (r.label) {
              case 0:
                return [4, e.asyncGetTargetElementBySelector(".weui-desktop-layout__main__inner")];
              case 1:
                return t = r.sent(), n = function () {
                  var e = document.querySelector("#app");
                  return !!e && "hidden" !== e.style.visibility
                }, [2, new Promise(function (e) {
                  if (n()) e();
                  else {
                    var r = new MutationObserver(function () {
                      n() && (r.disconnect(), e(null))
                    });
                    r.observe(t, {
                      childList: !0,
                      subtree: !0
                    })
                  }
                })]
            }
          })
        })
      }, e.waitImageLoaded = function (e) {
        return new Promise(function (t) {
          var n = document.createElement("img");
          n.src = e;
          try {
            n.complete ? t(n) : (n.onload = function () {
              t(n)
            }, n.onerror = function () {
              t(null)
            })
          } catch (e) {
            t(null)
          }
        })
      }, e.isPlatformActivating = function (e) {
        return new Set(["wxapp", "mp"]).has(e)
      }, e.getPlatformColor = function (e) {
        var t = {
          mp: "#24BE58",
          wxapp: "#605aae"
        }[e];
        return t || "black"
      }, e.getErrorMessage = function (e) {
        return e instanceof Error ? e.message : e
      }, e.copyText = function (e) {
        var t = document.createElement("textarea");
        t.setAttribute("readonly", "readonly"), t.value = e, document.body.appendChild(t), t.setSelectionRange(0, 9999), t.select();
        var n = document.execCommand("copy");
        return document.body.removeChild(t), n
      }, e.injectIconfontScripts = function () {
        if (location.href.match(/:\/\/mp.weixin.qq.com\//)) {
          var e = document.createElement("script");
          e.src = chrome.extension.getURL("assets/libs/iconfont.js"), e.setAttribute("mpa-script", "t"), document.head.appendChild(e)
        }
      }
    }(o = t.utils || (t.utils = {})), window && (window.yb_extension_utils = o)
  },
  23: function (e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.compose = function () {
      for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
      return 0 === e.length ? function (e) {
        return e
      } : 1 === e.length ? e[0] : e.reduce(function (e, t) {
        return function () {
          for (var n = [], r = 0; r < arguments.length; r++) n[r] = arguments[r];
          return e(t.apply(void 0, n))
        }
      })
    }
  },
  29: function (e, t, n) {
    "use strict";
    HTMLCanvasElement.prototype.toBlob || (HTMLCanvasElement.prototype.toBlob = function (e, t, n) {
      for (var r = atob(this.toDataURL(t, n).split(",")[1]), i = r.length, o = new Uint8Array(i), a = 0; a < i; a++) o[a] = r.charCodeAt(a);
      e(new Blob([o], {
        type: t || "image/png"
      }))
    })
  },
  3: function (e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.IMG_HI_RES_SUFFIX = "@2x", t.MPA_WINDOW_PROPERTY_IN_CONTENT = "mpaThisIsContentNotBrowserPage", t.SCORE_TITLE_TIP_NOT_SHOW_FLAG = "mpa.titleAssistantContent.scoreTitleTipNotShowFlag", t.DEFAULT_REMAIN_COUNT = 40, t.SUBSCRIBLE_PANE_UNFOLD_FLAG = "mpa.indexToolPanel.subscribePanel.unfold", t.SHOW_ANALYSIS_FLAG = "mpa.indexToolPanel.analysisLink.showTipFlag", t.INSERT_NEW_EDITOR_TOOL_FLAG = "mpa.wxEditorToolsPanel.insertEditorToolFlag", t.SHOW_BUY_DRIVING_REPLY_VIP_TIP_FLAG = "mpa.wxMessagesEnhance.showBuyDrivingReplyVipTipFlagVipDialogFlag", t.SHWO_ARTICLE_READ_FIRST_SEND_DELAY_FLAG = "mpa.titleAssistant.showArticleReadFirstSendDelayFlag", t.SHOW_ARTICLE_READ_FIST_FULFIL__FLAG = "mpa.titleAssistant.showArticleReadFirstFulfilTipFlag", t.SHOW_TITLE_RECOMMONED_NEW_TAG_FLAG = "mpa.titleRecommend.showTitleRecommendNewTagFlag", t.SHOW_VIOLATION_DETECTION_WELCOME_DIALOG_FLAG = "mpa.ViolationDetection.showViolationDetectionWelcomeDialogFlag", t.SHOW_TITLE_MARK_PROMPT_FLAG = "mpa.titleAssistant.shownAssistantPromptFlag", t.SHWO_TITLE_ASSISTANT_INTRO_DIALOG_FLAG = "mpa.titleAssistant.showTitleAssistantIntroDialogFlag", t.WX_EDITOR_TOOL_NEW_MARK_READED_LIST_FLAG = "mpa.wxEditorTool.newMarkReadedList", t.TEMPLATE_PANEL_TOOL_NEW_MARK_READED_LIST_FLAG = "mpa.templatePanelTool.newMarkReadedList", t.CHANNEL_QR_CODE_NEW_TIP_FLAG = "mpa.channelQrCode.newFlag", t.CHANNEL_QR_CODE_SHOW_INTRO_FLAG = "mpa.channelQrCode.showIntroFlag", t.MPA_DIALOG_PARENT_NO_SCROLL_CLASS = "mpa-dialog-parent-no-scroll", t.SHOW_USER_TAG_DRIVING_REPLY_TIP_FLAG = "mpa.userTagEnhance.showUserTagDrivingReplyTipFlag", t.SHOW_YEAR_REPORT_WELCOME_DIALOG_FLAG = "mpa.YearReportGenerater.showYearReportWelcomeDialogFlag", t.MPA_HAS_FINISHED_MASS_SEND_FETCH_TASK = "has-finished-mass-send-fetch-task-mpa-list", t.MPA_MASS_SEND_SHOW_INTRO_FLAG = "mpa.contactMsgSend.showIntroFlag", t.MPA_MASS_SEND_SAVE_INFO = "mpa.contactMsgSend.saveInfo", t.ADVANCED_FOLLOW_REPLY_INTRO_FLAG = "mpa.advancedFollowReply.showIntroFlag", t.EXPAND_GUIDE_DISMISSED_FLAG = "editor_templatePanelExpandGuideDismissed", t.EDITOR_SHOW_EXPANSION_HINT = "mpa.templatePanel.showHint", t.SHOW_MPA_SMART_SCREEN_TIP_FLAG = "mpa.editEnhance.showSmartScreenTipFlag", t.CLOSED_YEAR_REPORT_GENERATER_ENTRY = "mpa.yearReport.closedYearReportGeneraterEntry", t.CLOSED_YEAR_REPORT_ENTRY_ON_MP_DATA_PANEL = "mpa.yearReport.closedYearReportEntryOnMpDataPanel", t.HAS_SHOWN_CLOSE_YEAR_REPORT_ENTRY_HINT = "mpa.yearReport.hasShownCloseYearReportEntryHint", t.WX_EDITOR_PAGE_NOTIFICATION_PANEL_LAST_HIDE_VERSION_FLAG = "mpa.wxEditorPageNotificationPanelLastHideVersionFlag", t.WX_EDITOR_PAGE_NOTIFICATION_PANEL_DEFAULT_SHOWN_VERSION_FLAG = "mpa.wxEditorPageNotificationPanelDefaultShownVersionFlag", t.LAST_SHOW_RENEW_VIP_DIALOG_TIMESTAMP_STORAGE_KEY = "mpa.lastShowRenewVipDialogTimestampStorageKey", t.LAST_SHOW_OLD_USER_RENEW_WELFARE_FLAG_STORAGE_KEY = "mpa.lastShowOldUserRenewWelfareFlagStorageKey", t.LAST_SHOW_RENEW_VIP_TIPS_BOX_TIMESTAMP_STORAGE_KEY = "mpa.lastShowRenewVipTipsBoxTimestampStorageKey", t.HIDE_AUTO_TAGGING_NEW_FLAG = "mpa.hideAutoTaggingNewFlag", t.SHOW_TOP_HUB_WELCOME_PAGE_FLAG = "mpa.templatePage.newTopHub.showTopHubWelcomePageFlag", t.FIRST_OPEN_MATERIAL_DIALOG_FLAG = "mpa.templatePanel.material.firstOpenMaterialDialogFlag", t.HIDE_CHANNEL_QRCODE_DATA_PROMPT = "mpa.hideChannelQrcodeDataPrompt", t.SHOW_FANS_STORAGE_TIP_FLAG = "mpa.toolPanelView.fansStorageTipFlag", t.HIDE_FANS_RETENTION_ANALYSIS_NEW_FLAG = "mpa-hideFansRetentionAnalysisNewFlag", t.SHOW_FANS_RETENTION_ANALYSIS_INTRO_DIALOG_FLAG = "mpa-showFansRetentionAnalysisIntroDialogFlag", t.SHOW_FANS_RETENTION_DATA_START_TIME_PROMPT_FLAG = "mpa-showFansRetentionDataStartTimePromptFlag", t.MP_REPORT_DATA_FETCH_TIME = "mpa-mpReportDataFetchTime", t.SHOW_ADVANCED_MASS_SEND_NEW_FLAG = "mpa-showAdvancedMassSendNewFlag", t.SHOW_TEMPLATE_MASS_SEND_NEW_FLAG = "mpa-showTemplateMassSendNewFlag", t.FREE_FUNCTION_GUIDE_DIALOG_SHOW_TIME_RECORDS = "mpa-freeFunctionGuideDialogShowTimeRecords", t.FREE_FUNCTION_USE_TIME_RECORDS = "mpa-freeFunctionUseTimeRecords", t.NEVER_SHOW_FREE_FUNCTION_DIALOG = "mpa-neverShowFreeFunctionDialog", t.HIDE_SCHEDULED_SEND_BUTTON_TIP_FLAG = "mpa-hideScheduledSendButtonTipFlag", t.DEFAULT_INDEX_PANEL_TOOLS = [{
      key: "laboratory",
      list: ["mass-send", "follow-reply"]
    }, "data-report", "export-data", {
      key: "cancel-analyse",
      list: ["cancel-rate-analyse", "cancel-list"]
    }, "open-rate", "channel-qr-code", "raise-hour", "violate-detection", "copyright-detection"], t.DEFAULT_INDEX_PANEL_TOOLS_V2 = [{
      category: "功能实验室",
      list: [{
        category: "渠道码",
        type: "channel-qr-code"
      }, {
        category: "个性推送",
        type: "advanced-mass-send"
      }, {
        category: "模板通知",
        type: "template-mass-send"
      }, {
        category: "客服推送",
        type: "mass-send"
      }, {
        category: "高级关注回复",
        type: "follow-reply"
      }]
    }, {
      category: "图文分析",
      list: [{
        category: "数据报告",
        type: "data-report"
      }, {
        category: "导出图文数据",
        type: "export-data"
      }, {
        category: "打开率分析",
        type: "open-rate"
      }]
    }, {
      category: "粉丝分析",
      list: [{
        category: "留存分析",
        type: "fans-retention-analysis"
      }, {
        category: "取关率分析",
        type: "cancel-rate-analyse"
      }, {
        category: "增长小时报",
        type: "raise-hour"
      }, {
        category: "取关列表",
        type: "cancel-list"
      }, {
        category: "自动打标签",
        type: "auto-tagging"
      }]
    }], t.DEFAULT_WX_EDITOR_TOOLS = ["forever-link", "insert-chart", "micro-program", "generate-pic", "generate-voice", "image-center", "import-article", "import-word", "micro-program", "phone-image", "qr-code", "title-test", "before-posting-violation-detection"], t.DEFAULT_POPUP_HOME_PAGE_TOOL_LIST = [{
      category: "常用功能",
      tools: [{
        name: "壹伴后台",
        key: "yiban-backstage",
        icon: "https://cdn.yiban.io/extension-assets/popup/icon__datas-v1.svg",
        type: "link",
        link: "https://yiban.io/dashboard/"
      }, {
        name: "采集文章",
        key: "gather-article",
        icon: "https://cdn.yiban.io/extension-assets/popup/icon__gather-article-v1.svg",
        type: "feature"
      }, {
        name: "网页截屏",
        key: "clip-page",
        icon: "https://cdn.yiban.io/extension-assets/popup/icon__clip-page-v1.svg",
        type: "feature"
      }, {
        name: "题图制作",
        key: "image_editor",
        icon: "https://cdn.yiban.io/extension-assets/popup/icon__image-editor-v1.svg",
        type: "link",
        link: "https://yiban.io/image_editor"
      }, {
        name: "云笔记",
        key: "note-cloude",
        icon: "https://cdn.yiban.io/extension-assets/popup/icon__note-v1.svg",
        type: "link",
        link: "https://note.yiban.io/"
      }]
    }, {
      category: "壹伴服务",
      tools: [{
        name: "问题检测",
        key: "check-question",
        icon: "https://cdn.yiban.io/extension-assets/popup/icon__check-question-v1.svg",
        type: "link",
        link: "https://yiban.io/detection"
      }, {
        name: "问答社区",
        key: "q-a",
        icon: "https://cdn.yiban.io/extension-assets/popup/icon__feedback-v1.svg",
        type: "link",
        link: "https://yiban.io/blog/ask?from=popup"
      }]
    }, {
      category: "新功能介绍",
      tools: [{
        name: "标题评分",
        key: "mark-title",
        icon: "https://cdn.yiban.io/extension-assets/popup/icon__mark-title-v1.svg",
        type: "link",
        link: "https://mp.weixin.qq.com/s?__biz=MzI4MDUzMTg2NQ==&mid=2247492961&idx=1&sn=eff9f524719d48295946d73ec0b2a252&chksm=ebb5a397dcc22a814206ab37e24322e1400f5737d365bed27ab054b3f8515a90ceaffee2003a&scene=27#wechat_redirect"
      }, {
        name: "内容版权检测",
        key: "check-copyright",
        icon: "https://cdn.yiban.io/extension-assets/popup/icon__check-copyright-v1.svg",
        type: "link",
        link: "https://mp.weixin.qq.com/s?__biz=MzI4MDUzMTg2NQ==&mid=2247492800&idx=1&sn=a6ea1d4e14bdc841cec47b98e0be5a02&chksm=ebb5a236dcc22b2093b49498c902f4ce72b5b7b0868e6a3e86a996f05bd87c311fdd0fef498f&scene=27#wechat_redirect"
      }]
    }], t.MAP_WEIBO_TYPE_TO_CLASS = {
      "热": "weibo-type-hot",
      "新": "weibo-type-new",
      "荐": "weibo-type-recommand",
      "#": "weibo-type-topic"
    }, t.WX_EDITOR_TOOL_INIT_DATA = [{
      category: "import-article",
      type: "common",
      title: "导入文章",
      new: !1,
      eventType: "importArticle"
    }, {
      category: "import-word",
      type: "common",
      title: "导入Word",
      new: !1,
      eventType: "importWord"
    }, {
      category: "qr-code",
      type: "common",
      title: "生成二维码",
      new: !1,
      eventType: "genQrCode"
    }, {
      category: "phone-image",
      type: "common",
      title: "手机传图",
      new: !1,
      eventType: "phoneImage"
    }, {
      category: "image-center",
      type: "common",
      title: "配图中心",
      new: !1,
      eventType: "imageCenter"
    }, {
      category: "generate-pic",
      type: "common",
      title: "生成长图",
      new: !1
    }, {
      category: "title-test",
      type: "common",
      title: "标题评分",
      new: !1
    }, {
      category: "forever-link",
      type: "common",
      title: "永久链接",
      new: !1,
      eventType: "foreverLink"
    }, {
      category: "before-posting-violation-detection",
      title: "违规检测",
      type: "common",
      new: !1
    }, {
      category: "channel-code",
      title: "渠道码",
      type: "common",
      new: !1
    }, {
      category: "history-article-recommend",
      title: "往期推荐",
      type: "common",
      new: !0
    }, {
      category: "marketing-calendar",
      title: "营销日历",
      type: "common",
      new: !1
    }, {
      category: "short-link-generator",
      title: "短链接生成器",
      type: "common",
      new: !1
    }, {
      category: "micro-program",
      type: "recommand",
      title: "壹伴小程序",
      new: !1
    }, {
      category: "insert-chart",
      type: "recommand",
      title: "插入图表",
      new: !1
    }], t.WX_EDITOR_TOOL_INIT_DATA_V2 = [{
      category: "效率工具",
      tools: [{
        category: "import-article",
        type: "common",
        title: "导入文章",
        new: !1,
        eventType: "importArticle"
      }, {
        category: "import-word",
        type: "common",
        title: "导入Word",
        new: !1,
        eventType: "importWord"
      }, {
        category: "qr-code",
        type: "common",
        title: "生成二维码",
        new: !1,
        eventType: "genQrCode"
      }, {
        category: "generate-pic",
        type: "common",
        title: "生成长图",
        new: !1
      }, {
        category: "forever-link",
        type: "common",
        title: "永久链接",
        new: !1,
        eventType: "foreverLink"
      }, {
        category: "insert-chart",
        type: "recommand",
        title: "插入图表",
        new: !1
      }]
    }, {
      category: "特色功能",
      tools: [{
        category: "title-test",
        type: "common",
        title: "标题评分",
        new: !1
      }, {
        category: "before-posting-violation-detection",
        title: "违规检测",
        type: "common",
        new: !1
      }, {
        category: "history-article-recommend",
        title: "往期推荐",
        type: "common",
        new: !1
      }]
    }, {
      category: "推荐使用",
      tools: [{
        category: "channel-code",
        title: "渠道码",
        type: "common",
        new: !1
      }]
    }, {
      category: "运营工具",
      tools: [{
        category: "micro-program",
        type: "recommand",
        title: "壹伴小程序",
        new: !1
      }]
    }], t.WX_EDITOR_IMAGE_TAB_LIST_DATA = [{
      type: "emotion",
      desc: "表情包",
      isSelected: !0,
      vipIcon: !1
    }, {
      type: "gif-img",
      desc: "GIF动图",
      isSelected: !1,
      vipIcon: !1
    }, {
      type: "upload",
      desc: "我的上传",
      isSelected: !1,
      vipIcon: !0
    }], t.NEWS_CENTER_ITEM_LIST = [{
      value: "热点榜单",
      selected: !0,
      name: "hotSpots"
    }, {
      value: "事件",
      selected: !1,
      name: "events"
    }], t.HOT_SPOTS_PLATFORM_LIST = [{
      value: "微博热搜",
      platform: [{
        name: "热搜榜",
        type: "weibo_hot"
      }, {
        name: "新时代",
        type: "weibo_event"
      }],
      selected: !0
    }, {
      value: "知乎热搜",
      platform: [{
        name: "知乎热搜",
        type: "zhihu_hot"
      }],
      selected: !1
    }, {
      value: "百度热搜",
      platform: [{
        name: "实时热点",
        type: "baidu_realtime"
      }],
      selected: !1
    }], t.QQ_READ_NAME_VALUE = [{
      type: "all",
      name: "全部",
      selected: !0
    }, {
      type: "sports",
      name: "体育",
      selected: !1
    }, {
      type: "fun",
      name: "娱乐",
      selected: !1
    }, {
      type: "fashion",
      name: "时尚",
      selected: !1
    }, {
      type: "game",
      name: "游戏",
      selected: !1
    }, {
      type: "food",
      name: "美食",
      selected: !1
    }, {
      type: "emotion",
      name: "情感",
      selected: !1
    }, {
      type: "anime",
      name: "动漫",
      selected: !1
    }, {
      type: "health",
      name: "健康",
      selected: !1
    }, {
      type: "car",
      name: "汽车",
      selected: !1
    }, {
      type: "culture",
      name: "文化",
      selected: !1
    }], t.QQ_VIDEO_NAME_VALUE = [{
      type: "all",
      name: "全部",
      selected: !0
    }, {
      type: "children",
      name: "少儿",
      selected: !1
    }, {
      type: "anime",
      name: "动漫",
      selected: !1
    }, {
      type: "sports",
      name: "体育",
      selected: !1
    }, {
      type: "film",
      name: "电影",
      selected: !1
    }, {
      type: "car",
      name: "汽车",
      selected: !1
    }, {
      type: "technology",
      name: "科技",
      selected: !1
    }, {
      type: "food",
      name: "美食",
      selected: !1
    }, {
      type: "life",
      name: "生活",
      selected: !1
    }], t.TEMPLATE_CATEGORY_LIST = [{
      type: "fav",
      name: "我的",
      zIndex: 16
    }, {
      type: "hot",
      name: "热门",
      zIndex: 15
    }, {
      type: "template",
      name: "模板",
      zIndex: 14
    }, {
      type: "background",
      name: "背景",
      zIndex: 13
    }, {
      type: "blackTech",
      name: "动效",
      zIndex: 12,
      isNew: !0
    }, {
      type: "title",
      name: "标题",
      zIndex: 11
    }, {
      type: "body",
      name: "正文",
      zIndex: 10
    }, {
      type: "QA",
      name: "问答",
      zIndex: 9,
      isNew: !0
    }, {
      type: "image",
      name: "图文",
      zIndex: 8
    }, {
      type: "divider",
      name: "分隔",
      zIndex: 7
    }, {
      type: "guide",
      name: "引导",
      zIndex: 6
    }, {
      type: "festival",
      name: "节日",
      zIndex: 5
    }, {
      type: "style",
      name: "风格",
      zIndex: 4
    }, {
      type: "industry",
      name: "行业",
      zIndex: 3
    }, {
      type: "more",
      name: "更多",
      zIndex: 2
    }], t.MATERIAL_HOT_TAB_LIST = [{
      name: "热点",
      id: "hot"
    }, {
      name: "最新",
      id: "new"
    }, {
      name: "精选",
      id: "goods"
    }], t.MATERIAL_COLLECT_TAB_LIST = [{
      name: "我的收藏",
      id: "my_collection"
    }, {
      name: "最近使用",
      id: "recent_use"
    }], t.MATERIAL_SYSTEM_TAB_LIST = [{
      name: "系统模板",
      id: "system"
    }, {
      name: "个人模板",
      id: "user"
    }, {
      name: "模板收藏",
      id: "collection"
    }], t.BACKGROUND_TAB_LIST = [{
      name: "背景素材",
      id: "system_background"
    }, {
      name: "自定义背景",
      id: "my_background",
      needVip: !0
    }], t.MATERIAL_ACTION_BTN_LIST = [{
      name: "ID",
      type: "ID",
      visible: !1
    }, {
      name: "深色预览",
      type: "dark-mode",
      visible: !0
    }, {
      name: "按住拖动",
      type: "drag",
      visible: !1
    }, {
      name: "置顶",
      type: "pin-top",
      visible: !1
    }, {
      name: "取消置顶",
      type: "un-pin-top",
      visible: !1
    }, {
      name: "样式推荐",
      type: "recommend",
      visible: !1
    }, {
      name: "编辑",
      type: "editor",
      visible: !1
    }, {
      name: "收藏",
      type: "collect",
      visible: !1
    }, {
      name: "取消收藏",
      type: "faved",
      visible: !1
    }, {
      name: "设置",
      type: "setting",
      visible: !1
    }, {
      name: "删除",
      type: "delete",
      visible: !1
    }], t.TOP_HUB_TODAY_CATEGORY_LIST = [{
      category: "综合类",
      id: 1
    }, {
      category: "科技类",
      id: 2
    }, {
      category: "娱乐类",
      id: 3
    }, {
      category: "社区类",
      id: 4
    }, {
      category: "电商类",
      id: 5
    }, {
      category: "财经类",
      id: 6
    }, {
      category: "博客类",
      id: 10
    }], t.TOP_HUB_TODAY_WELCOME_CATEGORY_LIST = [{
      category: "综合",
      id: 1,
      type: "zong-he"
    }, {
      category: "科技",
      id: 2,
      type: "ke-ji"
    }, {
      category: "娱乐",
      id: 3,
      type: "yu-le"
    }, {
      category: "社区",
      id: 4,
      type: "she-qu"
    }, {
      category: "电商",
      id: 5,
      type: "dian-shang"
    }, {
      category: "财经",
      id: 6,
      type: "chan-jin"
    }, {
      category: "博客",
      id: 10,
      type: "bo-ke"
    }], t.NEED_USE_NEW_TITLE_ASSISTANT_PLANTFORM = ["weixin"], t.DEFAULT_VIP_BUNDLE_LIST = [{
      desc: "简单好用的任务宝裂变涨粉工具",
      detail: "30天任务宝使用权",
      icon: "https://cdn.yiban.io/vip_icon/meixiangdao.jpg",
      worth: "价值¥999"
    }, {
      desc: "好用易操作的任务宝涨粉神器",
      detail: "15天任务宝使用权",
      icon: "https://cdn.yiban.io/vip-bundle-image/xingyao.png",
      worth: "价值¥590"
    }, {
      desc: "海量优质设计模板的在线设计平台",
      detail: "高级版使用权一年",
      icon: "https://cdn.yiban.io/vip_icon/fotor.jpg",
      worth: "价值¥38"
    }, {
      desc: "6000个h5模板以及h5进阶实操课程",
      detail: "VIP月卡",
      icon: "https://cdn.yiban.io/vip_icon/rrx.jpg",
      worth: "价值¥99"
    }, {
      desc: "免费创建H5小游戏的工具",
      detail: "100元代金券",
      icon: "https://cdn.yiban.io/vip-bundle-image/fankehudong.png",
      worth: "价值¥100"
    }, {
      desc: "自动收集数据表单工具",
      detail: "50元代金券",
      icon: "https://cdn.yiban.io/vip_icon/jinshuju.jpg",
      worth: "价值¥50"
    }, {
      desc: "在线问卷调查网站",
      detail: "30天会员",
      icon: "https://cdn.yiban.io/vip-bundle-image/wenjuanwang.png",
      worth: "价值¥29"
    }, {
      desc: "一键生成思维导图",
      detail: "3个月vip",
      icon: "https://cdn.yiban.io/vip_icon/mubu.jpg",
      worth: "价值¥27"
    }], t.DEFAULT_MP_APP_MSG_ANALYSIS_ALL_DATA_GATHER_INTERVAL = 1e4, t.DEFAULT_MP_APP_MSG_ANALYSIS_DETAIL_DATA_GATHER_INTERVAL = 5e3, t.IMG_PROXY_HOST = "wximg.yiban.io", t.WX_IMG_HOST = "mmbiz.qpic.cn", t.PROXIED_IMG_URL_REG = /https?:\/\/wximg.yiban.io\/img_proxy\?src=/, t.PROXIED_WX_IMG_URL_REG = /https?:\/\/wximg.yiban.io\/img_proxy\?src=https?:\/\/mmbiz.qpic.cn/g, t.BASE64_IMG_REG = /^\s*data:([a-z]+\/[a-z0-9-+.]+(;[a-z-]+=[a-z0-9-]+)?)?(;base64)?,([a-z0-9!$&',()*+;=\-._~:@\/?%\s]*?)\s*$/i, t.MAX_UPLOAD_IMG_SIZE = 1024e4, t.DEFAULT_LIST_DATA_FETCH_COUNT = 20, t.ATTR_IS_TPL = "data-mpa-template", t.ATTR_IS_TPL_VALUE = "t", t.ATTR_TPL_ID = "data-mpa-template-id", t.ATTR_TPL_COLOR = "data-mpa-color", t.ATTR_TPL_CATEGORY = "data-mpa-category", t.ATTR_DYNAMIC_MATERIAL_CATEGORY = "data-mpa-dynamic-material-category", t.ATTR_IS_DYNAMIC_MATERIAL = "data-mpa-dynamic-material", t.ATTR_PRESERVE_TPL_COLOR = "data-mpa-preserve-tpl-color", t.SUBSCRIBE_SCENE = [{
      name: "公众号搜索",
      scene: "ADD_SCENE_SEARCH"
    }, {
      name: "公众号迁移",
      scene: "ADD_SCENE_ACCOUNT_MIGRATION"
    }, {
      name: "名片分享",
      scene: "ADD_SCENE_PROFILE_CARD"
    }, {
      name: "扫描二维码",
      scene: "ADD_SCENE_QR_CODE"
    }, {
      name: "图文页内名称点击",
      scene: "ADD_SCENE_PROFILE_LINK"
    }, {
      name: "图文页右上角菜单",
      scene: "ADD_SCENE_PROFILE_ITEM"
    }, {
      name: "支付后关注",
      scene: "ADD_SCENE_PAID"
    }, {
      name: "微信广告",
      scene: "ADD_SCENE_WECHAT_ADVERTISEMENT"
    }, {
      name: "他人转载",
      scene: "ADD_SCENE_REPRINT"
    }, {
      name: "视频号直播",
      scene: "ADD_SCENE_LIVESTREAM"
    }, {
      name: "视频号",
      scene: "ADD_SCENE_CHANNELS"
    }, {
      name: "其他",
      scene: "ADD_SCENE_OTHERS"
    }], t.DEFAULT_MP_ARTICLE_COVER = "https://cdn.yiban.io/common/default-article-cover-v2.png", t.FIRST_GATHER_TIMES = 10, t.AGAIN_GATHER_TIMES = 2, t.AGAIN_ATTEMPT_REQUEST_TIMES = 3, t.HISTORY_ARTICLE_RECOMMEND_ARTICLE_DATA_FLAG = "mpa.history.article.recommend.article.data", t.IS_CLOSE_AI_WRITING_ENTRY_ALERT = "mpa.templatePanel.aiWrting.entryAlert", t.AI_WRITING_ENTRY_SHOW_TIME = "mpa.templatePanel.aiWriting.entryShowTime", t.AI_WRITING_FREE_COUNTDOWN_SHOW_TIME = "mpa.templatePanel.aiWriting.freeCountdownShowTime", t.AI_ENTRY_SWITCH_FLAG = "mpa.templatePanel.aiWriting.entrySwitchFlag", t.AI_ENTRY_HAS_SHOWN_ANIMATION = "mpa.templatePanel.aiWriting.aiEntryHasShownAnimation", t.AI_FIRST_Receive_Use = "mpa.templatePanel.aiWriting.aiFirstReceiveUse", t.HAS_SHOWN_AI_DISCOUNT_MODAL = "mpa.templatePanel.aiWriting.hasShownAiDiscountModal", t.HAS_SHOWN_IMG_NEW_FLAG = "mpa.templatePanel.titleBar.hasShownImgNewFlag", t.BLACK_TECH_UPDATE_VERSION = "9.0.16"
  },
  332: function (e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
      value: !0
    });
    var r = n(333);
    n(29), console.log("Bootstrap editor"), window._mpaEditorInjected ? console.log("-- skip edior Bootstrap for there's an exist one") : (window._mpaEditorInjected = !0, $(document).ready(function () {
      new r.EditorBootstraper
    }))
  },
  333: function (e, t, n) {
    "use strict";
    var r = this && this.__assign || function () {
      return (r = Object.assign || function (e) {
        for (var t, n = 1, r = arguments.length; n < r; n++)
          for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
        return e
      }).apply(this, arguments)
    },
      i = this && this.__awaiter || function (e, t, n, r) {
        return new (n || (n = Promise))(function (i, o) {
          function a(e) {
            try {
              c(r.next(e))
            } catch (e) {
              o(e)
            }
          }

          function s(e) {
            try {
              c(r.throw(e))
            } catch (e) {
              o(e)
            }
          }

          function c(e) {
            e.done ? i(e.value) : new n(function (t) {
              t(e.value)
            }).then(a, s)
          }
          c((r = r.apply(e, t || [])).next())
        })
      },
      o = this && this.__generator || function (e, t) {
        var n, r, i, o, a = {
          label: 0,
          sent: function () {
            if (1 & i[0]) throw i[1];
            return i[1]
          },
          trys: [],
          ops: []
        };
        return o = {
          next: s(0),
          throw: s(1),
          return: s(2)
        }, "function" == typeof Symbol && (o[Symbol.iterator] = function () {
          return this
        }), o;

        function s(o) {
          return function (s) {
            return function (o) {
              if (n) throw new TypeError("Generator is already executing.");
              for (; a;) try {
                if (n = 1, r && (i = 2 & o[0] ? r.return : o[0] ? r.throw || ((i = r.return) && i.call(r), 0) : r.next) && !(i = i.call(r, o[1])).done) return i;
                switch (r = 0, i && (o = [2 & o[0], i.value]), o[0]) {
                  case 0:
                  case 1:
                    i = o;
                    break;
                  case 4:
                    return a.label++, {
                      value: o[1],
                      done: !1
                    };
                  case 5:
                    a.label++, r = o[1], o = [0];
                    continue;
                  case 7:
                    o = a.ops.pop(), a.trys.pop();
                    continue;
                  default:
                    if (!(i = (i = a.trys).length > 0 && i[i.length - 1]) && (6 === o[0] || 2 === o[0])) {
                      a = 0;
                      continue
                    }
                    if (3 === o[0] && (!i || o[1] > i[0] && o[1] < i[3])) {
                      a.label = o[1];
                      break
                    }
                    if (6 === o[0] && a.label < i[1]) {
                      a.label = i[1], i = o;
                      break
                    }
                    if (i && a.label < i[2]) {
                      a.label = i[2], a.ops.push(o);
                      break
                    }
                    i[2] && a.ops.pop(), a.trys.pop();
                    continue
                }
                o = t.call(e, a)
              } catch (e) {
                o = [6, e], r = 0
              } finally {
                  n = i = 0
                }
              if (5 & o[0]) throw o[1];
              return {
                value: o[0] ? o[1] : void 0,
                done: !0
              }
            }([o, s])
          }
        }
      };
    Object.defineProperty(t, "__esModule", {
      value: !0
    });
    var a = n(4),
      s = n(1),
      c = function () {
        function e() {
          var e = this;
          this.extensionEventListeners = {};
          var t = document.body.getAttribute("mpa-extension-id");
          this.extensionId = t, this.sessionId = s.utils.genSessionId();
          this.getStorageData(["devMode", "hosts", "editorTemplatePanelAutoExpand", "editorExtraPicToolsVisible", "editorExtraToolsVisible", "enableBandu", "enablePermanentPreview", "editorExtraToolbarButtonPanelVisible", "editorContentCheckerVisible", "aiQuickActionVisible", "aiWordWritingVisible", "enableTextDirectionalityTool"]).then(function (n) {
            return i(e, void 0, void 0, function () {
              var e, r, i;
              return o(this, function (o) {
                switch (o.label) {
                  case 0:
                    return [4, s.utils.asyncGetTargetElementBySelector("#ueditor_0")];
                  case 1:
                    return o.sent(), e = this.getUEditorInstance(), r = n.devMode, i = n.hosts.web, this.storageData = n, this.wxEditorPlugin = new WXEditorPlugin({
                      extensionId: t,
                      host: i,
                      devMode: r,
                      uEditor: e,
                      apiProxy: {
                        get: this.get.bind(this),
                        post: this.post.bind(this)
                      },
                      eventProxy: {
                        sendEvent: this.proxiedSendEvent.bind(this),
                        listenExtensionEvent: this.createEventListener.bind(this),
                        unlistenExtensionEvent: this.removeEventListener.bind(this)
                      },
                      panelsVisibility: this.getEditorPluginPanelsVisibility()
                    }), this.establishEventSocket(), [2]
                }
              })
            })
          }).catch(function (e) {
            console.error("无法初始化壹伴编辑器"), console.error(e)
          })
        }
        return e.prototype.getStorageData = function (e) {
          var t = this;
          return new Promise(function (n, r) {
            a.externalEvents.getStorageDatas(t.extensionId, {
              keys: e
            }).success(function (e) {
              var t = e.data;
              n(t)
            }).fail(function (e) {
              r(e)
            })
          })
        }, e.prototype.get = function (e, t, n, r, i) {
          var o = this;
          return new Promise(function (s, c) {
            var l = !i;
            a.externalEvents.apiGet(o.extensionId, {
              path: e,
              urlArgs: t,
              isWebApi: n,
              isBanduApi: r,
              handleRes: l
            }).success(function (e) {
              s(e.data)
            }).fail(function (e) {
              alert(e), c(e)
            })
          })
        }, e.prototype.post = function (e, t, n, r, i, o) {
          var s = this;
          return new Promise(function (c, l) {
            var u = !o;
            a.externalEvents.apiPost(s.extensionId, {
              path: e,
              urlArgs: t,
              bodyArgs: n,
              isWebApi: r,
              isBanduApi: i,
              handleRes: u
            }).success(function (e) {
              c(e.data)
            }).fail(function (e) {
              alert(e), l(e)
            })
          })
        }, e.prototype.proxiedSendEvent = function (e, t) {
          var n = this;
          return new Promise(function (i, o) {
            var a = r({
              event: e
            }, t);
            try {
              chrome.runtime.sendMessage(n.extensionId, a, function (e) {
                i(e)
              })
            } catch (e) {
              o(e), window.alert("无法与插件通信，请刷新页面后重试")
            }
          }).then(function (t) {
            return new Promise(function (n) {
              switch (e) {
                case "editorGatherArticle":
                  if (!t.success) return n(t);
                  var r = t.articleData,
                    i = {
                      imgurl: r.cover,
                      t: "ajax-editor-upload-img"
                    },
                    o = s.utils.getUrlArgs().token;
                  $.post("https://mp.weixin.qq.com/cgi-bin/uploadimg2cdn?lang=zh_CN&token=" + o, i).done(function (e) {
                    if (e.errcode) return console.error("封面图上传失败", e), n({
                      success: !1,
                      message: "封面图上传失败，请检查网络后重试",
                      wxRes: e
                    });
                    console.log("got uploaded cover"), console.log("old:", r.cover), console.log("new:", e.url), r.cover = e.url, n(t)
                  }).fail(function (e) {
                    console.error("封面图上传失败", e), n({
                      success: !1,
                      message: "封面图上传失败，请检查网络后重试"
                    })
                  });
                  break;
                default:
                  n(t)
              }
            })
          })
        }, e.prototype.createEventListener = function (e, t) {
          this.extensionEventListeners[e] || (this.extensionEventListeners[e] = []);
          var n = s.utils.genSessionId();
          return this.extensionEventListeners[e].push({
            id: n,
            event: e,
            callback: t
          }), n
        }, e.prototype.removeEventListener = function (e, t) {
          var n = this.extensionEventListeners[e];
          return !!n && (this.extensionEventListeners[e] = t ? n.filter(function (e) {
            return e.id !== t
          }) : [], n.length !== this.extensionEventListeners[e].length)
        }, e.prototype.updatePanelsVisibility = function () {
          this.wxEditorPlugin && this.wxEditorPlugin.updatePanelsVisibility(this.getEditorPluginPanelsVisibility())
        }, e.prototype.establishEventSocket = function (e) {
          var t = this;
          void 0 === e && (e = 500);
          try {
            a.externalEvents.listenEditorEvent(this.extensionId, {
              sessionId: this.sessionId
            }).success(function (e) {
              var n = e.event,
                r = e.data;
              try {
                t.handleExtensionEvent(n, r)
              } catch (e) {
                console.error(e)
              }
              setTimeout(function () {
                t.establishEventSocket()
              }, 0)
            }).fail(function () {
              setTimeout(function () {
                t.establishEventSocket(2 * e)
              }, e)
            })
          } catch (n) {
            console.error(n), setTimeout(function () {
              t.establishEventSocket(2 * e)
            }, e)
          }
        }, e.prototype.handleExtensionEvent = function (e, t) {
          if (console.log("handle extension event", e, t), "modifySetting" === e) {
            var n = t,
              r = n.key,
              i = n.value;
            this.storageData[r] = i, this.updatePanelsVisibility()
          }
          if (console.log("current listeners", this.extensionEventListeners[e]), this.extensionEventListeners[e])
            for (var o = 0, a = this.extensionEventListeners[e]; o < a.length; o++) {
              a[o].callback(t)
            }
        }, e.prototype.getUEditorInstance = function () {
          try {
            return window.baidu.editor.instants.ueditorInstant0
          } catch (e) {
            return
          }
        }, e.prototype.getEditorPluginPanelsVisibility = function () {
          var e = this.storageData,
            t = e.editorExtraPicToolsVisible,
            n = e.editorExtraToolbarButtonPanelVisible,
            r = e.editorExtraToolsVisible,
            i = e.editorTemplatePanelAutoExpand;
          return {
            enableBandu: e.enableBandu,
            enablePermanentPreview: e.enablePermanentPreview,
            editorExtraToolsVisible: r,
            editorExtraPicToolsVisible: t,
            editorTemplatePanelAutoExpand: i,
            editorExtraToolbarButtonPanelVisible: n,
            editorContentCheckerVisible: e.editorContentCheckerVisible,
            aiQuickActionVisible: e.aiQuickActionVisible,
            aiWordWritingVisible: e.aiWordWritingVisible,
            enableTextDirectionalityTool: e.enableTextDirectionalityTool
          }
        }, e
      }();
    t.EditorBootstraper = c
  },
  4: function (e, t, n) {
    "use strict";
    var r = this && this.__assign || function () {
      return (r = Object.assign || function (e) {
        for (var t, n = 1, r = arguments.length; n < r; n++)
          for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
        return e
      }).apply(this, arguments)
    };
    Object.defineProperty(t, "__esModule", {
      value: !0
    });
    var i = function () {
      function e(e, t) {
        this.event = e, this.sender = t
      }
      return e.prototype.success = function (e) {
        return this.onSuccess = e, this
      }, e.prototype.fail = function (e) {
        return this.onFail = e, this
      }, e.prototype.send = function (e, t, n) {
        var i = this;
        if (!this.wasSend) {
          this.wasSend = !0;
          var o = r({
            event: this.event
          }, e);
          try {
            "content" === this.type ? (o.type = "contentEvent", t ? chrome.tabs.sendMessage(t, o, function (e) {
              i.handleSendRes(i.event, e, o.type)
            }) : chrome.runtime.sendMessage(o, function (e) {
              i.handleSendRes(i.event, e, o.type)
            })) : "external" === this.type ? (o.type = "externalEvent", chrome.runtime.sendMessage(n, o, function (e) {
              i.handleSendRes(i.event, e, o.type)
            })) : (o.type = "internalEvent", chrome.runtime.sendMessage(o, function (e) {
              i.handleSendRes(i.event, e, o.type)
            }))
          } catch (e) {
            console.error("Unable to send extension message:", this.event), console.error(e);
            var a = "页面无法与插件通信，请确认插件正在运行后刷新本页面并重试";
            this.onFail && this.onFail(a, !0, {
              success: !1,
              message: a
            })
          }
        }
      }, e.prototype.handleSendRes = function (e, t, n) {
        t ? t.success ? this.onSuccess && this.onSuccess(t) : (console.error("Failed when trying to send msg:", e), console.error(t.message, t), this.onFail && this.onFail(t.message, !1, t)) : "contentEvent" === n ? (this.onFail && this.onFail("无法与插件前台", !0, null), console.error("Can't communicate with tab's content script, event:" + e)) : (this.onFail && this.onFail("无法与插件后台进行通讯，请刷新页面后重试", !0, null), console.error("Can't communicate with background script, event:" + e))
      }, e
    }();

    function o(e, t) {
      var n = function (r, o) {
        var a = new i(e, n);
        if (a.type = t, "internal" === t) {
          var s = r;
          a.send(s)
        } else if ("content" === t) {
          var c = r;
          s = o;
          a.send(s, c)
        } else if ("external" === t) {
          var l = r;
          s = o;
          if (!l) throw console.error("External event data", s), new Error("Can't find ExtensionId when trying to send external event!");
          a.send(s, void 0, l)
        }
        return a
      };
      return n
    }

    function a(e) {
      return o(e, "internal")
    }

    function s(e) {
      return o(e, "content")
    }

    function c(e) {
      return o(e, "external")
    } ! function (e) {
      e.apiGet = a("apiGet"), e.apiPost = a("apiPost"), e.proxiedGet = a("proxiedGet"), e.proxiedPost = a("proxiedPost"), e.setAuthState = a("setAuthState"), e.getTabId = a("getTabId"), e.requestLogin = a("requestLogin"), e.requestAddMp = a("requestAddMp"), e.updateMpList = a("updateMpList"), e.updateAccounts = a("updateAccounts"), e.gatherImageToMp = a("gatherImageToMp"), e.gatherImageToCloudNote = a("gatherImageToCloudNote"), e.gatherVideoToCloudNote = a("gatherVideoToCloudNote"), e.gatherTextToCloudNote = a("gatherTextToCloudNote"), e.gatherImageToBlackhole = a("gatherImageToBlackhole"), e.gatherMpArticle = a("gatherMpArticle"), e.backgroundTriggerGatherArticle = a("backgroundTriggerGatherArticle"), e.createNotification = a("createNotification"), e.getImageBase64DataUrl = a("getImageBase64DataUrl"), e.clipPage = a("clipPage"), e.editImage = a("editImage"), e.syncUserNotifications = a("syncUserNotifications"), e.syncUserInfo = a("syncUserInfo"), e.checkFeaturesStatus = a("checkFeaturesStatus"), e.genPermanentPreviewLink = a("genPermanentPreviewLink");
      var t = a("sendEditorEvent");
      e.sendEditorEvent = function (e) {
        return t(e)
      }, e.trackUserAction = a("trackUserAction"), e.trackUserEvent = a("trackUserEvent"), e.contentScriptError = a("contentScriptError"), e.registerAppmsgAnalysisHijack = a("registerAppmsgAnalysisHijack"), e.unregisterAppmsgAnalysisHijack = a("unregisterAppmsgAnalysisHijack"), e.hijackNextAppmsgAnalysis = a("hijackNextAppmsgAnalysis"), e.getLocalStorageData = a("getLocalStorageData"), e.setLocalStorageData = a("setLocalStorageData"), e.getLogLevel = a("getLogLevel");
      var n = a("sendMpRequest");
      e.sendMpRequest = function (e, t) {
        return n({
          fetcherName: e,
          params: t
        })
      }, e.createChromeTab = a("createChromeTab"), e.tryAuthByCookie = a("tryAuthByCookie"), e.clearYibanCookies = a("clearYibanCookie"), e.getImageDataList = a("getImageDataList"), e.deleteImageOfGroup = a("deleteImageOfGroup"), e.editorIframeEvent = a("editorIframeEvent"), e.sendGatherSuccessSignal = a("sendGatherSuccessSignal"), e.sendVerificationCode = a("sendVerificationCode"), e.refreshCookieByExtensionToken = a("refreshCookieByExtensionToken"), e.syncVipBundleList = a("syncVipBundleList"), e.syncVipGiftRemainCount = a("syncVipGiftRemainCount"), e.uploadMultiArticleToMp = a("uploadMultiArticleToMp"), e.uploadArticleToMp = a("uploadArticleToMp"), e.fetchCOSSImageData = a("fetchCOSSImageData"), e.randomGenAvatar = a("randomGenAvatar"), e.checkTargetMpIsVerifiedByWxApi = a("checkTargetMpIsVerifiedByWxApi"), e.checkTargetMpCanWxVerify = a("checkTargetMpCanWxVerify"), e.getAddMpPageUrl = a("getAddMpPageUrl"), e.openCustomerServicePage = a("openCustomerServicePage")
    }(t.internalEvents || (t.internalEvents = {})),
      function (e) {
        e.cssUpdated = s("cssUpdated"), e.showNotification = s("showNotification"), e.updateNotification = s("updateNotification"), e.triggerClipPage = s("triggerClipPage"), e.triggerGatherArticle = s("triggerGatherArticle"), e.gifEditComplete = s("gifEditComplete"), e.genPermanentPreviewLink = s("genPermanentPreviewLink"), e.imageDeleteCount = s("imageDeleteCount"), e.fetchUserInfo = s("fetchUserInfo"), e.triggerEditorIframeAction = s("triggerEditorIframeAction"), e.enterNotificationCenter = s("enterNotificationCenter"), e.triggerNoteUpdate = s("triggerNoteUpdate"), e.showBuyAiDialog = s("showBuyAiDialog")
      }(t.contentEvents || (t.contentEvents = {})),
      function (e) {
        e.apiGet = c("apiGet"), e.apiPost = c("apiPost"), e.listenEditorEvent = c("listenEditorEvent"), e.logout = c("logout"), e.getStorageDatas = c("getStorageDatas"), e.createChromeTab = a("createChromeTab"), e.showBuyVipDialog = c("showBuyVipDialog"), e.insertIntelligentWritingText = c("insertIntelligentWritingText"), e.deleteTemplateSet = c("deleteTemplateSet"), e.updateMaterial = c("updateMaterial"), e.sendUploadImageList = c("sendUploadImageList")
      }(t.externalEvents || (t.externalEvents = {}))
  }
});