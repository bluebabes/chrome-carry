## 常用 js

```
[
    {
        "name": "Baidu",
        "icon": "icons/baidu.png",
        "action": "https://www.baidu.com/s?wd=%s",
        "newtab": false,
        "css_style": "height: 70px; margin-top: -10px;"
    },
    {
        "name": "Google",
        "icon": "icons/google.png",
        "action": "https://google.com/search?q=%s",
        "newtab": false,
        "css_style": "height: 40px; margin: 15px 10px;"
    },
    {
        "name": "Yandex",
        "icon": "icons/yandex.png",
        "action": "https://yandex.com/search?text=%s",
        "newtab": false,
        "css_style": "height: 40px; padding: 15px 10px;"
    },
    {
        "name": "javbus",
        "icon": "icons/javbus.png",
        "action": "https://javbus.com/%s",
        "newtab": true,
        "css_style": "height: 45px; padding: 10px;"
    },
    {
        "name": "bt4g",
        "icon": "https://bt4g.org/static/logo.png",
        "action": "https://bt4g.org/search/%s",
        "newtab": true,
        "css_style": "height: 45px; padding: 10px;"
    },
    {
        "name": "rarbg",
        "icon": "https://rargb.to/static/img/logo_dark_nodomain2_optimized.png",
        "action": "https://rargb.to/search/?search=%s",
        "newtab": true,
        "css_style": "height: 45px; padding: 10px;"
    }
]
```
