import { s as u, e as o, n as f } from "./_virtual_wxt-plugins-CW914ZAk.js";
const c = u.defineItem("local:taskAlarms", {
  fallback: []
});
async function w() {
  const e = await c.getValue();
  if (!(e != null && e.length))
    return;
  const a = await chrome.alarms.getAll().catch(n => (console.error(n),
    []));
  for (const n of e) {
    if (!n.enabled)
      continue;
    if (!a.find(r => n.id === r.name)) {
      let r = n.when;
      if (r && n.periodInMinutes)
        for (; r < Date.now();)
          r += n.periodInMinutes * 60 * 1e3;
      await chrome.alarms.create(n.id, {
        periodInMinutes: n.periodInMinutes,
        delayInMinutes: n.delayInMinutes,
        when: r
      }).catch(s => {
        console.error(s)
      }
      )
    }
  }
}
const h = async e => {
  const a = await c.getValue();
  a.unshift(e),
    await c.setValue(a),
    e.enabled && await chrome.alarms.create(e.id, {
      periodInMinutes: e.periodInMinutes,
      delayInMinutes: e.delayInMinutes,
      when: e.when
    })
}
  , d = async (e, a) => {
    const n = await c.getValue();
    if (n.forEach(t => {
      t.id === e && (t.name = a.name,
        t.enabled = a.enabled,
        t.when = a.when,
        t.delayInMinutes = a.delayInMinutes,
        t.periodInMinutes = a.periodInMinutes)
    }
    ),
      await chrome.alarms.clear(e).catch(() => { }
      ),
      await c.setValue(n),
      a.enabled) {
      let t = a.when;
      if (t && a.periodInMinutes)
        for (; t < Date.now();)
          t += a.periodInMinutes * 60 * 1e3;
      await chrome.alarms.create(e, {
        periodInMinutes: a.periodInMinutes,
        delayInMinutes: a.delayInMinutes,
        when: t
      })
    }
  }
  , I = async e => {
    const a = await c.getValue();
    await (f() ? await chrome.alarms.clear(e).catch(() => { }
    ) : o("chrome", {
      paths: ["alarms", "clear"],
      args: [e]
    })),
      await c.setValue(a.filter(n => n.id !== e))
  }
  ;
function M(e, a = 1e3, n = 5e3) {
  return new Promise((t, r) => {
    const s = Date.now()
      , l = async () => {
        const i = await e();
        i ? t(i) : Date.now() - s >= n ? r(new Error("等待超时.")) : setTimeout(l, a)
      }
      ;
    l()
  }
  )
}
function g(e) {
  return new Promise(a => setTimeout(a, e))
}
const p = (e, a) => {
  if (!e && !a)
    return 0;
  if (!e)
    return -1;
  if (!a)
    return 1;
  const n = e.split(".")
    , t = a.split(".")
    , r = Math.max(n.length, t.length);
  for (let s = 0; s < r; s++) {
    const l = parseInt(n[s] || "0")
      , i = parseInt(t[s] || "0");
    if (l > i)
      return 1;
    if (l < i)
      return -1
  }
  return 0
}
  ;
function y(e, a) {
  if (e == null || e === void 0)
    return;
  let n;
  if (typeof e == "string") {
    let t = String(e).trim().replace(/[￥¥,]/g, "");
    const r = {
      W: 1e4,
      w: 1e4,
      K: 1e3,
      k: 1e3,
      千: 1e3,
      万: 1e4,
      亿: 1e8
    }
      , s = t.match(/^([+-]?[\d.]+)([a-zA-Z\u4e00-\u9fa5]*)\+?$/);
    if (!s)
      return;
    let [, l, i] = s;
    n = Number(l),
      n && i && r[i] && (n *= r[i])
  } else if (typeof e == "number")
    n = e;
  else {
    console.warn("不支持的数据类型");
    return
  }
  if (!isNaN(n) && !(a != null && a.skipZero && n === 0))
    return a != null && a.scale ? parseFloat(n.toFixed(a == null ? void 0 : a.scale)) : n
}
function b(e) {
  if (!e)
    return;
  const a = Math.floor(e / 3600)
    , n = Math.floor(e % 3600 / 60)
    , t = e % 60;
  return a > 0 ? `${a}小时${n}分${t}秒` : n > 0 ? `${n}分${t}秒` : `${t}秒`
}
export { p as a, h as b, w as c, b as f, y as p, I as r, g as s, c as t, d as u, M as w };
