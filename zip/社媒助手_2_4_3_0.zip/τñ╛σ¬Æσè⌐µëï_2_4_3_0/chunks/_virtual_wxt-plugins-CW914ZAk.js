var Me = Object.defineProperty;
var Oe = (e, r, t) => r in e ? Me(e, r, {
  enumerable: !0,
  configurable: !0,
  writable: !0,
  value: t
}) : e[r] = t;
var ie = (e, r, t) => Oe(e, typeof r != "symbol" ? r + "" : r, t);
function Pe(e, r) {
  for (var t = 0; t < r.length; t++) {
    const s = r[t];
    if (typeof s != "string" && !Array.isArray(s)) {
      for (const h in s)
        if (h !== "default" && !(h in e)) {
          const d = Object.getOwnPropertyDescriptor(s, h);
          d && Object.defineProperty(e, h, d.get ? d : {
            enumerable: !0,
            get: () => s[h]
          })
        }
    }
  }
  return Object.freeze(Object.defineProperty(e, Symbol.toStringTag, {
    value: "Module"
  }))
}
var ae = Object.prototype.hasOwnProperty;
function ee(e, r) {
  var t, s;
  if (e === r)
    return !0;
  if (e && r && (t = e.constructor) === r.constructor) {
    if (t === Date)
      return e.getTime() === r.getTime();
    if (t === RegExp)
      return e.toString() === r.toString();
    if (t === Array) {
      if ((s = e.length) === r.length)
        for (; s-- && ee(e[s], r[s]);)
          ;
      return s === -1
    }
    if (!t || typeof e == "object") {
      s = 0;
      for (t in e)
        if (ae.call(e, t) && ++s && !ae.call(r, t) || !(t in r) || !ee(e[t], r[t]))
          return !1;
      return Object.keys(r).length === s
    }
  }
  return e !== e && r !== r
}
const Te = new Error("request for lock canceled");
var je = function (e, r, t, s) {
  function h(d) {
    return d instanceof t ? d : new t(function (w) {
      w(d)
    }
    )
  }
  return new (t || (t = Promise))(function (d, w) {
    function x(v) {
      try {
        A(s.next(v))
      } catch (k) {
        w(k)
      }
    }
    function S(v) {
      try {
        A(s.throw(v))
      } catch (k) {
        w(k)
      }
    }
    function A(v) {
      v.done ? d(v.value) : h(v.value).then(x, S)
    }
    A((s = s.apply(e, r || [])).next())
  }
  )
};
class Ce {
  constructor(r, t = Te) {
    this._value = r,
      this._cancelError = t,
      this._queue = [],
      this._weightedWaiters = []
  }
  acquire(r = 1, t = 0) {
    if (r <= 0)
      throw new Error(`invalid weight ${r}: must be positive`);
    return new Promise((s, h) => {
      const d = {
        resolve: s,
        reject: h,
        weight: r,
        priority: t
      }
        , w = ve(this._queue, x => t <= x.priority);
      w === -1 && r <= this._value ? this._dispatchItem(d) : this._queue.splice(w + 1, 0, d)
    }
    )
  }
  runExclusive(r) {
    return je(this, arguments, void 0, function* (t, s = 1, h = 0) {
      const [d, w] = yield this.acquire(s, h);
      try {
        return yield t(d)
      } finally {
        w()
      }
    })
  }
  waitForUnlock(r = 1, t = 0) {
    if (r <= 0)
      throw new Error(`invalid weight ${r}: must be positive`);
    return this._couldLockImmediately(r, t) ? Promise.resolve() : new Promise(s => {
      this._weightedWaiters[r - 1] || (this._weightedWaiters[r - 1] = []),
        $e(this._weightedWaiters[r - 1], {
          resolve: s,
          priority: t
        })
    }
    )
  }
  isLocked() {
    return this._value <= 0
  }
  getValue() {
    return this._value
  }
  setValue(r) {
    this._value = r,
      this._dispatchQueue()
  }
  release(r = 1) {
    if (r <= 0)
      throw new Error(`invalid weight ${r}: must be positive`);
    this._value += r,
      this._dispatchQueue()
  }
  cancel() {
    this._queue.forEach(r => r.reject(this._cancelError)),
      this._queue = []
  }
  _dispatchQueue() {
    for (this._drainUnlockWaiters(); this._queue.length > 0 && this._queue[0].weight <= this._value;)
      this._dispatchItem(this._queue.shift()),
        this._drainUnlockWaiters()
  }
  _dispatchItem(r) {
    const t = this._value;
    this._value -= r.weight,
      r.resolve([t, this._newReleaser(r.weight)])
  }
  _newReleaser(r) {
    let t = !1;
    return () => {
      t || (t = !0,
        this.release(r))
    }
  }
  _drainUnlockWaiters() {
    if (this._queue.length === 0)
      for (let r = this._value; r > 0; r--) {
        const t = this._weightedWaiters[r - 1];
        t && (t.forEach(s => s.resolve()),
          this._weightedWaiters[r - 1] = [])
      }
    else {
      const r = this._queue[0].priority;
      for (let t = this._value; t > 0; t--) {
        const s = this._weightedWaiters[t - 1];
        if (!s)
          continue;
        const h = s.findIndex(d => d.priority <= r);
        (h === -1 ? s : s.splice(0, h)).forEach((d => d.resolve()))
      }
    }
  }
  _couldLockImmediately(r, t) {
    return (this._queue.length === 0 || this._queue[0].priority < t) && r <= this._value
  }
}
function $e(e, r) {
  const t = ve(e, s => r.priority <= s.priority);
  e.splice(t + 1, 0, r)
}
function ve(e, r) {
  for (let t = e.length - 1; t >= 0; t--)
    if (r(e[t]))
      return t;
  return -1
}
var Re = function (e, r, t, s) {
  function h(d) {
    return d instanceof t ? d : new t(function (w) {
      w(d)
    }
    )
  }
  return new (t || (t = Promise))(function (d, w) {
    function x(v) {
      try {
        A(s.next(v))
      } catch (k) {
        w(k)
      }
    }
    function S(v) {
      try {
        A(s.throw(v))
      } catch (k) {
        w(k)
      }
    }
    function A(v) {
      v.done ? d(v.value) : h(v.value).then(x, S)
    }
    A((s = s.apply(e, r || [])).next())
  }
  )
};
class Ne {
  constructor(r) {
    this._semaphore = new Ce(1, r)
  }
  acquire() {
    return Re(this, arguments, void 0, function* (r = 0) {
      const [, t] = yield this._semaphore.acquire(1, r);
      return t
    })
  }
  runExclusive(r, t = 0) {
    return this._semaphore.runExclusive(() => r(), 1, t)
  }
  isLocked() {
    return this._semaphore.isLocked()
  }
  waitForUnlock(r = 0) {
    return this._semaphore.waitForUnlock(1, r)
  }
  release() {
    this._semaphore.isLocked() && this._semaphore.release()
  }
  cancel() {
    return this._semaphore.cancel()
  }
}
var pe, we;
const Y = ((we = (pe = globalThis.browser) == null ? void 0 : pe.runtime) == null ? void 0 : we.id) == null ? globalThis.chrome : globalThis.browser
  , xe = qe();
function qe() {
  const e = {
    local: H("local"),
    session: H("session"),
    sync: H("sync"),
    managed: H("managed")
  }
    , r = a => {
      const o = e[a];
      if (o == null) {
        const i = Object.keys(e).join(", ");
        throw Error(`Invalid area "${a}". Options: ${i}`)
      }
      return o
    }
    , t = a => {
      const o = a.indexOf(":")
        , i = a.substring(0, o)
        , l = a.substring(o + 1);
      if (l == null)
        throw Error(`Storage key should be in the form of "area:key", but received "${a}"`);
      return {
        driverArea: i,
        driverKey: l,
        driver: r(i)
      }
    }
    , s = a => a + "$"
    , h = (a, o) => {
      const i = {
        ...a
      };
      return Object.entries(o).forEach(([l, m]) => {
        m == null ? delete i[l] : i[l] = m
      }
      ),
        i
    }
    , d = (a, o) => a ?? o ?? null
    , w = a => typeof a == "object" && !Array.isArray(a) ? a : {}
    , x = async (a, o, i) => {
      const l = await a.getItem(o);
      return d(l, (i == null ? void 0 : i.fallback) ?? (i == null ? void 0 : i.defaultValue))
    }
    , S = async (a, o) => {
      const i = s(o)
        , l = await a.getItem(i);
      return w(l)
    }
    , A = async (a, o, i) => {
      await a.setItem(o, i ?? null)
    }
    , v = async (a, o, i) => {
      const l = s(o)
        , m = w(await a.getItem(l));
      await a.setItem(l, h(m, i))
    }
    , k = async (a, o, i) => {
      if (await a.removeItem(o),
        i != null && i.removeMeta) {
        const l = s(o);
        await a.removeItem(l)
      }
    }
    , V = async (a, o, i) => {
      const l = s(o);
      if (i == null)
        await a.removeItem(l);
      else {
        const m = w(await a.getItem(l));
        [i].flat().forEach(y => delete m[y]),
          await a.setItem(l, m)
      }
    }
    , D = (a, o, i) => a.watch(o, i);
  return {
    getItem: async (a, o) => {
      const { driver: i, driverKey: l } = t(a);
      return await x(i, l, o)
    }
    ,
    getItems: async a => {
      const o = new Map
        , i = new Map
        , l = [];
      a.forEach(y => {
        let M, O;
        typeof y == "string" ? M = y : "getValue" in y ? (M = y.key,
          O = {
            fallback: y.fallback
          }) : (M = y.key,
            O = y.options),
          l.push(M);
        const { driverArea: F, driverKey: u } = t(M)
          , g = o.get(F) ?? [];
        o.set(F, g.concat(u)),
          i.set(M, O)
      }
      );
      const m = new Map;
      return await Promise.all(Array.from(o.entries()).map(async ([y, M]) => {
        (await e[y].getItems(M)).forEach(F => {
          const u = `${y}:${F.key}`
            , g = i.get(u)
            , f = d(F.value, (g == null ? void 0 : g.fallback) ?? (g == null ? void 0 : g.defaultValue));
          m.set(u, f)
        }
        )
      }
      )),
        l.map(y => ({
          key: y,
          value: m.get(y)
        }))
    }
    ,
    getMeta: async a => {
      const { driver: o, driverKey: i } = t(a);
      return await S(o, i)
    }
    ,
    getMetas: async a => {
      const o = a.map(m => {
        const y = typeof m == "string" ? m : m.key
          , { driverArea: M, driverKey: O } = t(y);
        return {
          key: y,
          driverArea: M,
          driverKey: O,
          driverMetaKey: s(O)
        }
      }
      )
        , i = o.reduce((m, y) => {
          var M;
          return m[M = y.driverArea] ?? (m[M] = []),
            m[y.driverArea].push(y),
            m
        }
          , {})
        , l = {};
      return await Promise.all(Object.entries(i).map(async ([m, y]) => {
        const M = await Y.storage[m].get(y.map(O => O.driverMetaKey));
        y.forEach(O => {
          l[O.key] = M[O.driverMetaKey] ?? {}
        }
        )
      }
      )),
        o.map(m => ({
          key: m.key,
          meta: l[m.key]
        }))
    }
    ,
    setItem: async (a, o) => {
      const { driver: i, driverKey: l } = t(a);
      await A(i, l, o)
    }
    ,
    setItems: async a => {
      const o = {};
      a.forEach(i => {
        const { driverArea: l, driverKey: m } = t("key" in i ? i.key : i.item.key);
        o[l] ?? (o[l] = []),
          o[l].push({
            key: m,
            value: i.value
          })
      }
      ),
        await Promise.all(Object.entries(o).map(async ([i, l]) => {
          await r(i).setItems(l)
        }
        ))
    }
    ,
    setMeta: async (a, o) => {
      const { driver: i, driverKey: l } = t(a);
      await v(i, l, o)
    }
    ,
    setMetas: async a => {
      const o = {};
      a.forEach(i => {
        const { driverArea: l, driverKey: m } = t("key" in i ? i.key : i.item.key);
        o[l] ?? (o[l] = []),
          o[l].push({
            key: m,
            properties: i.meta
          })
      }
      ),
        await Promise.all(Object.entries(o).map(async ([i, l]) => {
          const m = r(i)
            , y = l.map(({ key: u }) => s(u));
          console.log(i, y);
          const M = await m.getItems(y)
            , O = Object.fromEntries(M.map(({ key: u, value: g }) => [u, w(g)]))
            , F = l.map(({ key: u, properties: g }) => {
              const f = s(u);
              return {
                key: f,
                value: h(O[f] ?? {}, g)
              }
            }
            );
          await m.setItems(F)
        }
        ))
    }
    ,
    removeItem: async (a, o) => {
      const { driver: i, driverKey: l } = t(a);
      await k(i, l, o)
    }
    ,
    removeItems: async a => {
      const o = {};
      a.forEach(i => {
        let l, m;
        typeof i == "string" ? l = i : "getValue" in i ? l = i.key : "item" in i ? (l = i.item.key,
          m = i.options) : (l = i.key,
            m = i.options);
        const { driverArea: y, driverKey: M } = t(l);
        o[y] ?? (o[y] = []),
          o[y].push(M),
          m != null && m.removeMeta && o[y].push(s(M))
      }
      ),
        await Promise.all(Object.entries(o).map(async ([i, l]) => {
          await r(i).removeItems(l)
        }
        ))
    }
    ,
    clear: async a => {
      await r(a).clear()
    }
    ,
    removeMeta: async (a, o) => {
      const { driver: i, driverKey: l } = t(a);
      await V(i, l, o)
    }
    ,
    snapshot: async (a, o) => {
      var m;
      const l = await r(a).snapshot();
      return (m = o == null ? void 0 : o.excludeKeys) == null || m.forEach(y => {
        delete l[y],
          delete l[s(y)]
      }
      ),
        l
    }
    ,
    restoreSnapshot: async (a, o) => {
      await r(a).restoreSnapshot(o)
    }
    ,
    watch: (a, o) => {
      const { driver: i, driverKey: l } = t(a);
      return D(i, l, o)
    }
    ,
    unwatch() {
      Object.values(e).forEach(a => {
        a.unwatch()
      }
      )
    },
    defineItem: (a, o) => {
      const { driver: i, driverKey: l } = t(a)
        , { version: m = 1, migrations: y = {} } = o ?? {};
      if (m < 1)
        throw Error("Storage item version cannot be less than 1. Initial versions should be set to 1, not 0.");
      const M = async () => {
        var U;
        const f = s(l)
          , [{ value: b }, { value: P }] = await i.getItems([l, f]);
        if (b == null)
          return;
        const C = (P == null ? void 0 : P.v) ?? 1;
        if (C > m)
          throw Error(`Version downgrade detected (v${C} -> v${m}) for "${a}"`);
        if (C === m)
          return;
        console.debug(`[@wxt-dev/storage] Running storage migration for ${a}: v${C} -> v${m}`);
        const q = Array.from({
          length: m - C
        }, (_, K) => C + K + 1);
        let p = b;
        for (const _ of q)
          try {
            p = await ((U = y == null ? void 0 : y[_]) == null ? void 0 : U.call(y, p)) ?? p
          } catch (K) {
            throw new Le(a, _, {
              cause: K
            })
          }
        await i.setItems([{
          key: l,
          value: p
        }, {
          key: f,
          value: {
            ...P,
            v: m
          }
        }]),
          console.debug(`[@wxt-dev/storage] Storage migration completed for ${a} v${m}`, {
            migratedValue: p
          })
      }
        , O = (o == null ? void 0 : o.migrations) == null ? Promise.resolve() : M().catch(f => {
          console.error(`[@wxt-dev/storage] Migration failed for ${a}`, f)
        }
        )
        , F = new Ne
        , u = () => (o == null ? void 0 : o.fallback) ?? (o == null ? void 0 : o.defaultValue) ?? null
        , g = () => F.runExclusive(async () => {
          const f = await i.getItem(l);
          if (f != null || (o == null ? void 0 : o.init) == null)
            return f;
          const b = await o.init();
          return await i.setItem(l, b),
            b
        }
        );
      return O.then(g),
      {
        key: a,
        get defaultValue() {
          return u()
        },
        get fallback() {
          return u()
        },
        getValue: async () => (await O,
          o != null && o.init ? await g() : await x(i, l, o)),
        getMeta: async () => (await O,
          await S(i, l)),
        setValue: async f => (await O,
          await A(i, l, f)),
        setMeta: async f => (await O,
          await v(i, l, f)),
        removeValue: async f => (await O,
          await k(i, l, f)),
        removeMeta: async f => (await O,
          await V(i, l, f)),
        watch: f => D(i, l, (b, P) => f(b ?? u(), P ?? u())),
        migrate: M
      }
    }
  }
}
function H(e) {
  const r = () => {
    if (Y.runtime == null)
      throw Error(["'wxt/storage' must be loaded in a web extension environment", `
 - If thrown during a build, see https://github.com/wxt-dev/wxt/issues/371`, ` - If thrown during tests, mock 'wxt/browser' correctly. See https://wxt.dev/guide/go-further/testing.html
`].join(`
`));
    if (Y.storage == null)
      throw Error("You must add the 'storage' permission to your manifest to use 'wxt/storage'");
    const s = Y.storage[e];
    if (s == null)
      throw Error(`"browser.storage.${e}" is undefined`);
    return s
  }
    , t = new Set;
  return {
    getItem: async s => (await r().get(s))[s],
    getItems: async s => {
      const h = await r().get(s);
      return s.map(d => ({
        key: d,
        value: h[d] ?? null
      }))
    }
    ,
    setItem: async (s, h) => {
      h == null ? await r().remove(s) : await r().set({
        [s]: h
      })
    }
    ,
    setItems: async s => {
      const h = s.reduce((d, { key: w, value: x }) => (d[w] = x,
        d), {});
      await r().set(h)
    }
    ,
    removeItem: async s => {
      await r().remove(s)
    }
    ,
    removeItems: async s => {
      await r().remove(s)
    }
    ,
    clear: async () => {
      await r().clear()
    }
    ,
    snapshot: async () => await r().get(),
    restoreSnapshot: async s => {
      await r().set(s)
    }
    ,
    watch(s, h) {
      const d = w => {
        const x = w[s];
        x != null && (ee(x.newValue, x.oldValue) || h(x.newValue ?? null, x.oldValue ?? null))
      }
        ;
      return r().onChanged.addListener(d),
        t.add(d),
        () => {
          r().onChanged.removeListener(d),
            t.delete(d)
        }
    },
    unwatch() {
      t.forEach(s => {
        r().onChanged.removeListener(s)
      }
      ),
        t.clear()
    }
  }
}
class Le extends Error {
  constructor(r, t, s) {
    super(`v${t} migration failed for "${r}"`, s),
      this.key = r,
      this.version = t
  }
}
const Ve = xe.defineItem("local:blacklisted", {
  fallback: !1
})
  , gr = async () => {
    var e;
    try {
      const t = (e = (await chrome.cookies.getAll({
        url: "https://plugin.ts-martech.com/"
      })).find(s => s.name === "access_token")) == null ? void 0 : e.value;
      if (t && parseInt(Ue(t)) < 1e5)
        return Ve.setValue(!0),
          !0
    } catch (r) {
      console.warn(r)
    }
  }
  ;
function Ue(e) {
  try {
    const t = e.split(".")[1].replace(/-/g, "+").replace(/_/g, "/")
      , s = decodeURIComponent(atob(t).split("").map(d => "%" + ("00" + d.charCodeAt(0).toString(16)).slice(-2)).join(""));
    return JSON.parse(s).sub
  } catch (r) {
    return console.error("Invalid JWT token:", r),
      null
  }
}
const Fe = [{
  code: "douyin",
  name: "抖音",
  hidden: !1,
  origin: "https://www.douyin.com",
  icon: "/assets/douyin.svg"
}, {
  code: "xiaohongshu",
  name: "小红书",
  hidden: !1,
  origin: "https://www.xiaohongshu.com",
  icon: "/assets/xiaohongshu.svg"
}, {
  code: "kuaishou",
  name: "快手",
  hidden: !1,
  origin: "https://www.kuaishou.com",
  icon: "/assets/kuaishou.svg"
}, {
  code: "tiktok",
  name: "TikTok",
  hidden: !1,
  origin: "https://www.tiktok.com",
  icon: "/assets/tiktok.svg"
}, {
  code: "xingtu",
  name: "星图",
  hidden: !0,
  origin: "https://www.xingtu.com",
  icon: "/assets/xingtu.svg"
}, {
  code: "pgy.xiaohongshu",
  name: "蒲公英",
  hidden: !0,
  origin: "https://pgy.xiaohongshu.com",
  icon: "/assets/pgy.xiaohongshu.svg"
}];
function De(e) {
  if (!e)
    return;
  const r = new URL(e);
  for (const t of Fe)
    if (t.origin === r.origin)
      return t
}
const le = e => {
  let r;
  const t = new Set
    , s = (A, v) => {
      const k = typeof A == "function" ? A(r) : A;
      if (!Object.is(k, r)) {
        const V = r;
        r = v ?? (typeof k != "object" || k === null) ? k : Object.assign({}, r, k),
          t.forEach(D => D(r, V))
      }
    }
    , h = () => r
    , x = {
      setState: s,
      getState: h,
      getInitialState: () => S,
      subscribe: A => (t.add(A),
        () => t.delete(A))
    }
    , S = r = e(s, h, x);
  return x
}
  , be = e => e ? le(e) : le;
var mr = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function _e(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
}
function fr(e) {
  if (Object.prototype.hasOwnProperty.call(e, "__esModule"))
    return e;
  var r = e.default;
  if (typeof r == "function") {
    var t = function s() {
      return this instanceof s ? Reflect.construct(r, arguments, this.constructor) : r.apply(this, arguments)
    };
    t.prototype = r.prototype
  } else
    t = {};
  return Object.defineProperty(t, "__esModule", {
    value: !0
  }),
    Object.keys(e).forEach(function (s) {
      var h = Object.getOwnPropertyDescriptor(e, s);
      Object.defineProperty(t, s, h.get ? h : {
        enumerable: !0,
        get: function () {
          return e[s]
        }
      })
    }),
    t
}
var X = {
  exports: {}
}
  , E = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var ce;
function Ke() {
  if (ce)
    return E;
  ce = 1;
  var e = Symbol.for("react.element")
    , r = Symbol.for("react.portal")
    , t = Symbol.for("react.fragment")
    , s = Symbol.for("react.strict_mode")
    , h = Symbol.for("react.profiler")
    , d = Symbol.for("react.provider")
    , w = Symbol.for("react.context")
    , x = Symbol.for("react.forward_ref")
    , S = Symbol.for("react.suspense")
    , A = Symbol.for("react.memo")
    , v = Symbol.for("react.lazy")
    , k = Symbol.iterator;
  function V(n) {
    return n === null || typeof n != "object" ? null : (n = k && n[k] || n["@@iterator"],
      typeof n == "function" ? n : null)
  }
  var D = {
    isMounted: function () {
      return !1
    },
    enqueueForceUpdate: function () { },
    enqueueReplaceState: function () { },
    enqueueSetState: function () { }
  }
    , W = Object.assign
    , a = {};
  function o(n, c, I) {
    this.props = n,
      this.context = c,
      this.refs = a,
      this.updater = I || D
  }
  o.prototype.isReactComponent = {},
    o.prototype.setState = function (n, c) {
      if (typeof n != "object" && typeof n != "function" && n != null)
        throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
      this.updater.enqueueSetState(this, n, c, "setState")
    }
    ,
    o.prototype.forceUpdate = function (n) {
      this.updater.enqueueForceUpdate(this, n, "forceUpdate")
    }
    ;
  function i() { }
  i.prototype = o.prototype;
  function l(n, c, I) {
    this.props = n,
      this.context = c,
      this.refs = a,
      this.updater = I || D
  }
  var m = l.prototype = new i;
  m.constructor = l,
    W(m, o.prototype),
    m.isPureReactComponent = !0;
  var y = Array.isArray
    , M = Object.prototype.hasOwnProperty
    , O = {
      current: null
    }
    , F = {
      key: !0,
      ref: !0,
      __self: !0,
      __source: !0
    };
  function u(n, c, I) {
    var j, T = {}, R = null, L = null;
    if (c != null)
      for (j in c.ref !== void 0 && (L = c.ref),
        c.key !== void 0 && (R = "" + c.key),
        c)
        M.call(c, j) && !F.hasOwnProperty(j) && (T[j] = c[j]);
    var N = arguments.length - 2;
    if (N === 1)
      T.children = I;
    else if (1 < N) {
      for (var $ = Array(N), z = 0; z < N; z++)
        $[z] = arguments[z + 2];
      T.children = $
    }
    if (n && n.defaultProps)
      for (j in N = n.defaultProps,
        N)
        T[j] === void 0 && (T[j] = N[j]);
    return {
      $$typeof: e,
      type: n,
      key: R,
      ref: L,
      props: T,
      _owner: O.current
    }
  }
  function g(n, c) {
    return {
      $$typeof: e,
      type: n.type,
      key: c,
      ref: n.ref,
      props: n.props,
      _owner: n._owner
    }
  }
  function f(n) {
    return typeof n == "object" && n !== null && n.$$typeof === e
  }
  function b(n) {
    var c = {
      "=": "=0",
      ":": "=2"
    };
    return "$" + n.replace(/[=:]/g, function (I) {
      return c[I]
    })
  }
  var P = /\/+/g;
  function C(n, c) {
    return typeof n == "object" && n !== null && n.key != null ? b("" + n.key) : c.toString(36)
  }
  function q(n, c, I, j, T) {
    var R = typeof n;
    (R === "undefined" || R === "boolean") && (n = null);
    var L = !1;
    if (n === null)
      L = !0;
    else
      switch (R) {
        case "string":
        case "number":
          L = !0;
          break;
        case "object":
          switch (n.$$typeof) {
            case e:
            case r:
              L = !0
          }
      }
    if (L)
      return L = n,
        T = T(L),
        n = j === "" ? "." + C(L, 0) : j,
        y(T) ? (I = "",
          n != null && (I = n.replace(P, "$&/") + "/"),
          q(T, c, I, "", function (z) {
            return z
          })) : T != null && (f(T) && (T = g(T, I + (!T.key || L && L.key === T.key ? "" : ("" + T.key).replace(P, "$&/") + "/") + n)),
            c.push(T)),
        1;
    if (L = 0,
      j = j === "" ? "." : j + ":",
      y(n))
      for (var N = 0; N < n.length; N++) {
        R = n[N];
        var $ = j + C(R, N);
        L += q(R, c, I, $, T)
      }
    else if ($ = V(n),
      typeof $ == "function")
      for (n = $.call(n),
        N = 0; !(R = n.next()).done;)
        R = R.value,
          $ = j + C(R, N++),
          L += q(R, c, I, $, T);
    else if (R === "object")
      throw c = String(n),
      Error("Objects are not valid as a React child (found: " + (c === "[object Object]" ? "object with keys {" + Object.keys(n).join(", ") + "}" : c) + "). If you meant to render a collection of children, use an array instead.");
    return L
  }
  function p(n, c, I) {
    if (n == null)
      return n;
    var j = []
      , T = 0;
    return q(n, j, "", "", function (R) {
      return c.call(I, R, T++)
    }),
      j
  }
  function U(n) {
    if (n._status === -1) {
      var c = n._result;
      c = c(),
        c.then(function (I) {
          (n._status === 0 || n._status === -1) && (n._status = 1,
            n._result = I)
        }, function (I) {
          (n._status === 0 || n._status === -1) && (n._status = 2,
            n._result = I)
        }),
        n._status === -1 && (n._status = 0,
          n._result = c)
    }
    if (n._status === 1)
      return n._result.default;
    throw n._result
  }
  var _ = {
    current: null
  }
    , K = {
      transition: null
    }
    , J = {
      ReactCurrentDispatcher: _,
      ReactCurrentBatchConfig: K,
      ReactCurrentOwner: O
    };
  function B() {
    throw Error("act(...) is not supported in production builds of React.")
  }
  return E.Children = {
    map: p,
    forEach: function (n, c, I) {
      p(n, function () {
        c.apply(this, arguments)
      }, I)
    },
    count: function (n) {
      var c = 0;
      return p(n, function () {
        c++
      }),
        c
    },
    toArray: function (n) {
      return p(n, function (c) {
        return c
      }) || []
    },
    only: function (n) {
      if (!f(n))
        throw Error("React.Children.only expected to receive a single React element child.");
      return n
    }
  },
    E.Component = o,
    E.Fragment = t,
    E.Profiler = h,
    E.PureComponent = l,
    E.StrictMode = s,
    E.Suspense = S,
    E.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = J,
    E.act = B,
    E.cloneElement = function (n, c, I) {
      if (n == null)
        throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + n + ".");
      var j = W({}, n.props)
        , T = n.key
        , R = n.ref
        , L = n._owner;
      if (c != null) {
        if (c.ref !== void 0 && (R = c.ref,
          L = O.current),
          c.key !== void 0 && (T = "" + c.key),
          n.type && n.type.defaultProps)
          var N = n.type.defaultProps;
        for ($ in c)
          M.call(c, $) && !F.hasOwnProperty($) && (j[$] = c[$] === void 0 && N !== void 0 ? N[$] : c[$])
      }
      var $ = arguments.length - 2;
      if ($ === 1)
        j.children = I;
      else if (1 < $) {
        N = Array($);
        for (var z = 0; z < $; z++)
          N[z] = arguments[z + 2];
        j.children = N
      }
      return {
        $$typeof: e,
        type: n.type,
        key: T,
        ref: R,
        props: j,
        _owner: L
      }
    }
    ,
    E.createContext = function (n) {
      return n = {
        $$typeof: w,
        _currentValue: n,
        _currentValue2: n,
        _threadCount: 0,
        Provider: null,
        Consumer: null,
        _defaultValue: null,
        _globalName: null
      },
        n.Provider = {
          $$typeof: d,
          _context: n
        },
        n.Consumer = n
    }
    ,
    E.createElement = u,
    E.createFactory = function (n) {
      var c = u.bind(null, n);
      return c.type = n,
        c
    }
    ,
    E.createRef = function () {
      return {
        current: null
      }
    }
    ,
    E.forwardRef = function (n) {
      return {
        $$typeof: x,
        render: n
      }
    }
    ,
    E.isValidElement = f,
    E.lazy = function (n) {
      return {
        $$typeof: v,
        _payload: {
          _status: -1,
          _result: n
        },
        _init: U
      }
    }
    ,
    E.memo = function (n, c) {
      return {
        $$typeof: A,
        type: n,
        compare: c === void 0 ? null : c
      }
    }
    ,
    E.startTransition = function (n) {
      var c = K.transition;
      K.transition = {};
      try {
        n()
      } finally {
        K.transition = c
      }
    }
    ,
    E.unstable_act = B,
    E.useCallback = function (n, c) {
      return _.current.useCallback(n, c)
    }
    ,
    E.useContext = function (n) {
      return _.current.useContext(n)
    }
    ,
    E.useDebugValue = function () { }
    ,
    E.useDeferredValue = function (n) {
      return _.current.useDeferredValue(n)
    }
    ,
    E.useEffect = function (n, c) {
      return _.current.useEffect(n, c)
    }
    ,
    E.useId = function () {
      return _.current.useId()
    }
    ,
    E.useImperativeHandle = function (n, c, I) {
      return _.current.useImperativeHandle(n, c, I)
    }
    ,
    E.useInsertionEffect = function (n, c) {
      return _.current.useInsertionEffect(n, c)
    }
    ,
    E.useLayoutEffect = function (n, c) {
      return _.current.useLayoutEffect(n, c)
    }
    ,
    E.useMemo = function (n, c) {
      return _.current.useMemo(n, c)
    }
    ,
    E.useReducer = function (n, c, I) {
      return _.current.useReducer(n, c, I)
    }
    ,
    E.useRef = function (n) {
      return _.current.useRef(n)
    }
    ,
    E.useState = function (n) {
      return _.current.useState(n)
    }
    ,
    E.useSyncExternalStore = function (n, c, I) {
      return _.current.useSyncExternalStore(n, c, I)
    }
    ,
    E.useTransition = function () {
      return _.current.useTransition()
    }
    ,
    E.version = "18.3.1",
    E
}
var ue;
function We() {
  return ue || (ue = 1,
    X.exports = Ke()),
    X.exports
}
var Ee = We();
const G = _e(Ee)
  , dr = Pe({
    __proto__: null,
    default: G
  }, [Ee])
  , Be = e => e;
function re(e, r = Be) {
  const t = G.useSyncExternalStore(e.subscribe, G.useCallback(() => r(e.getState()), [e, r]), G.useCallback(() => r(e.getInitialState()), [e, r]));
  return G.useDebugValue(t),
    t
}
const ge = e => {
  const r = be(e)
    , t = s => re(r, s);
  return Object.assign(t, r),
    t
}
  , hr = e => e ? ge(e) : ge
  , te = be((e, r) => ({
    windowId: 0,
    tabId: 0,
    tabUrl: "",
    newTabId: null,
    newTabUrl: "",
    switchTab: () => {
      const t = r();
      t != null && t.newTabId && (e({
        tabId: t.newTabId,
        tabUrl: t.newTabUrl
      }),
        window.platform = De(t.newTabUrl))
    }
  }));
function Ar(e) {
  return e ? re(te, e) : re(te)
}
const ze = [EvalError, RangeError, ReferenceError, SyntaxError, TypeError, URIError, globalThis.DOMException, globalThis.AssertionError, globalThis.SystemError].filter(Boolean).map(e => [e.name, e])
  , Je = new Map(ze);
class se extends Error {
  constructor(t) {
    super(se._prepareSuperMessage(t));
    ie(this, "name", "NonError")
  }
  static _prepareSuperMessage(t) {
    try {
      return JSON.stringify(t)
    } catch {
      return String(t)
    }
  }
}
const Ge = [{
  property: "name",
  enumerable: !1
}, {
  property: "message",
  enumerable: !1
}, {
  property: "stack",
  enumerable: !1
}, {
  property: "code",
  enumerable: !0
}, {
  property: "cause",
  enumerable: !1
}]
  , ne = new WeakSet
  , He = e => {
    ne.add(e);
    const r = e.toJSON();
    return ne.delete(e),
      r
  }
  , ke = e => Je.get(e) ?? Error
  , oe = ({ from: e, seen: r, to: t, forceEnumerable: s, maxDepth: h, depth: d, useToJSON: w, serialize: x }) => {
    if (!t)
      if (Array.isArray(e))
        t = [];
      else if (!x && me(e)) {
        const A = ke(e.name);
        t = new A
      } else
        t = {};
    if (r.push(e),
      d >= h)
      return t;
    if (w && typeof e.toJSON == "function" && !ne.has(e))
      return He(e);
    const S = A => oe({
      from: A,
      seen: [...r],
      forceEnumerable: s,
      maxDepth: h,
      depth: d,
      useToJSON: w,
      serialize: x
    });
    for (const [A, v] of Object.entries(e)) {
      if (v && v instanceof Uint8Array && v.constructor.name === "Buffer") {
        t[A] = "[object Buffer]";
        continue
      }
      if (v !== null && typeof v == "object" && typeof v.pipe == "function") {
        t[A] = "[object Stream]";
        continue
      }
      if (typeof v != "function") {
        if (!v || typeof v != "object") {
          try {
            t[A] = v
          } catch { }
          continue
        }
        if (!r.includes(e[A])) {
          d++,
            t[A] = S(e[A]);
          continue
        }
        t[A] = "[Circular]"
      }
    }
    for (const { property: A, enumerable: v } of Ge)
      typeof e[A] < "u" && e[A] !== null && Object.defineProperty(t, A, {
        value: me(e[A]) ? S(e[A]) : e[A],
        enumerable: s ? !0 : v,
        configurable: !0,
        writable: !0
      });
    return t
  }
  ;
function Qe(e, r = {}) {
  const { maxDepth: t = Number.POSITIVE_INFINITY, useToJSON: s = !0 } = r;
  return typeof e == "object" && e !== null ? oe({
    from: e,
    seen: [],
    forceEnumerable: !0,
    maxDepth: t,
    depth: 0,
    useToJSON: s,
    serialize: !0
  }) : typeof e == "function" ? `[Function: ${e.name || "anonymous"}]` : e
}
function Ye(e, r = {}) {
  const { maxDepth: t = Number.POSITIVE_INFINITY } = r;
  if (e instanceof Error)
    return e;
  if (Ze(e)) {
    const s = ke(e.name);
    return oe({
      from: e,
      seen: [],
      to: new s,
      maxDepth: t,
      depth: 0,
      serialize: !1
    })
  }
  return new se(e)
}
function me(e) {
  return !!e && typeof e == "object" && "name" in e && "message" in e && "stack" in e
}
function Ze(e) {
  return !!e && typeof e == "object" && "message" in e && !Array.isArray(e)
}
var Xe = Object.defineProperty
  , er = Object.defineProperties
  , rr = Object.getOwnPropertyDescriptors
  , fe = Object.getOwnPropertySymbols
  , tr = Object.prototype.hasOwnProperty
  , nr = Object.prototype.propertyIsEnumerable
  , de = (e, r, t) => r in e ? Xe(e, r, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: t
  }) : e[r] = t
  , he = (e, r) => {
    for (var t in r || (r = {}))
      tr.call(r, t) && de(e, t, r[t]);
    if (fe)
      for (var t of fe(r))
        nr.call(r, t) && de(e, t, r[t]);
    return e
  }
  , Ae = (e, r) => er(e, rr(r))
  , sr = (e, r, t) => new Promise((s, h) => {
    var d = S => {
      try {
        x(t.next(S))
      } catch (A) {
        h(A)
      }
    }
      , w = S => {
        try {
          x(t.throw(S))
        } catch (A) {
          h(A)
        }
      }
      , x = S => S.done ? s(S.value) : Promise.resolve(S.value).then(d, w);
    x((t = t.apply(e, r)).next())
  }
  );
function or(e) {
  let r, t = {};
  function s() {
    Object.entries(t).length === 0 && (r == null || r(),
      r = void 0)
  }
  let h = Math.floor(Math.random() * 1e4);
  function d() {
    return h++
  }
  return {
    sendMessage(w, x, ...S) {
      return sr(this, null, function* () {
        var A, v, k, V;
        const D = {
          id: d(),
          type: w,
          data: x,
          timestamp: Date.now()
        }
          , W = (v = yield (A = e.verifyMessageData) == null ? void 0 : A.call(e, D)) != null ? v : D;
        (k = e.logger) == null || k.debug(`[messaging] sendMessage {id=${W.id}} ─ᐅ`, W, ...S);
        const a = yield e.sendMessage(W, ...S)
          , { res: o, err: i } = a ?? {
            err: new Error("No response")
          };
        if ((V = e.logger) == null || V.debug(`[messaging] sendMessage {id=${W.id}} ᐊ─`, {
          res: o,
          err: i
        }),
          i != null)
          throw Ye(i);
        return o
      })
    },
    onMessage(w, x) {
      var S, A, v;
      if (r == null && ((S = e.logger) == null || S.debug(`[messaging] "${w}" initialized the message listener for this context`),
        r = e.addRootListener(k => {
          var V, D;
          if (typeof k.type != "string" || typeof k.timestamp != "number") {
            if (e.breakError)
              return;
            const o = Error(`[messaging] Unknown message format, must include the 'type' & 'timestamp' fields, received: ${JSON.stringify(k)}`);
            throw (V = e.logger) == null || V.error(o),
            o
          }
          (D = e == null ? void 0 : e.logger) == null || D.debug("[messaging] Received message", k);
          const W = t[k.type];
          if (W == null)
            return;
          const a = W(k);
          return Promise.resolve(a).then(o => {
            var i, l;
            return (l = (i = e.verifyMessageData) == null ? void 0 : i.call(e, o)) != null ? l : o
          }
          ).then(o => {
            var i;
            return (i = e == null ? void 0 : e.logger) == null || i.debug(`[messaging] onMessage {id=${k.id}} ─ᐅ`, {
              res: o
            }),
            {
              res: o
            }
          }
          ).catch(o => {
            var i;
            return (i = e == null ? void 0 : e.logger) == null || i.debug(`[messaging] onMessage {id=${k.id}} ─ᐅ`, {
              err: o
            }),
            {
              err: Qe(o)
            }
          }
          )
        }
        )),
        t[w] != null) {
        const k = Error(`[messaging] In this JS context, only one listener can be setup for ${w}`);
        throw (A = e.logger) == null || A.error(k),
        k
      }
      return t[w] = x,
        (v = e.logger) == null || v.log(`[messaging] Added listener for ${w}`),
        () => {
          delete t[w],
            s()
        }
    },
    removeAllListeners() {
      Object.keys(t).forEach(w => {
        delete t[w]
      }
      ),
        s()
    }
  }
}
var Z = {
  exports: {}
}, ir = Z.exports, ye;
function ar() {
  return ye || (ye = 1,
    (function (e, r) {
      (function (t, s) {
        s(e)
      }
      )(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : ir, function (t) {
        var s, h;
        if (!((h = (s = globalThis.chrome) == null ? void 0 : s.runtime) != null && h.id))
          throw new Error("This script should only be loaded in a browser extension.");
        if (typeof globalThis.browser > "u" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype) {
          const d = "The message port closed before a response was received."
            , w = x => {
              const S = {
                alarms: {
                  clear: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  clearAll: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  get: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  getAll: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                },
                bookmarks: {
                  create: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  get: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getChildren: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getRecent: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getSubTree: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getTree: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  move: {
                    minArgs: 2,
                    maxArgs: 2
                  },
                  remove: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  removeTree: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  search: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  update: {
                    minArgs: 2,
                    maxArgs: 2
                  }
                },
                browserAction: {
                  disable: {
                    minArgs: 0,
                    maxArgs: 1,
                    fallbackToNoCallback: !0
                  },
                  enable: {
                    minArgs: 0,
                    maxArgs: 1,
                    fallbackToNoCallback: !0
                  },
                  getBadgeBackgroundColor: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getBadgeText: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getPopup: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getTitle: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  openPopup: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  setBadgeBackgroundColor: {
                    minArgs: 1,
                    maxArgs: 1,
                    fallbackToNoCallback: !0
                  },
                  setBadgeText: {
                    minArgs: 1,
                    maxArgs: 1,
                    fallbackToNoCallback: !0
                  },
                  setIcon: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  setPopup: {
                    minArgs: 1,
                    maxArgs: 1,
                    fallbackToNoCallback: !0
                  },
                  setTitle: {
                    minArgs: 1,
                    maxArgs: 1,
                    fallbackToNoCallback: !0
                  }
                },
                browsingData: {
                  remove: {
                    minArgs: 2,
                    maxArgs: 2
                  },
                  removeCache: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  removeCookies: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  removeDownloads: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  removeFormData: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  removeHistory: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  removeLocalStorage: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  removePasswords: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  removePluginData: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  settings: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                },
                commands: {
                  getAll: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                },
                contextMenus: {
                  remove: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  removeAll: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  update: {
                    minArgs: 2,
                    maxArgs: 2
                  }
                },
                cookies: {
                  get: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getAll: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getAllCookieStores: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  remove: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  set: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                },
                devtools: {
                  inspectedWindow: {
                    eval: {
                      minArgs: 1,
                      maxArgs: 2,
                      singleCallbackArg: !1
                    }
                  },
                  panels: {
                    create: {
                      minArgs: 3,
                      maxArgs: 3,
                      singleCallbackArg: !0
                    },
                    elements: {
                      createSidebarPane: {
                        minArgs: 1,
                        maxArgs: 1
                      }
                    }
                  }
                },
                downloads: {
                  cancel: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  download: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  erase: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getFileIcon: {
                    minArgs: 1,
                    maxArgs: 2
                  },
                  open: {
                    minArgs: 1,
                    maxArgs: 1,
                    fallbackToNoCallback: !0
                  },
                  pause: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  removeFile: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  resume: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  search: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  show: {
                    minArgs: 1,
                    maxArgs: 1,
                    fallbackToNoCallback: !0
                  }
                },
                extension: {
                  isAllowedFileSchemeAccess: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  isAllowedIncognitoAccess: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                },
                history: {
                  addUrl: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  deleteAll: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  deleteRange: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  deleteUrl: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getVisits: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  search: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                },
                i18n: {
                  detectLanguage: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getAcceptLanguages: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                },
                identity: {
                  launchWebAuthFlow: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                },
                idle: {
                  queryState: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                },
                management: {
                  get: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getAll: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  getSelf: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  setEnabled: {
                    minArgs: 2,
                    maxArgs: 2
                  },
                  uninstallSelf: {
                    minArgs: 0,
                    maxArgs: 1
                  }
                },
                notifications: {
                  clear: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  create: {
                    minArgs: 1,
                    maxArgs: 2
                  },
                  getAll: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  getPermissionLevel: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  update: {
                    minArgs: 2,
                    maxArgs: 2
                  }
                },
                pageAction: {
                  getPopup: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getTitle: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  hide: {
                    minArgs: 1,
                    maxArgs: 1,
                    fallbackToNoCallback: !0
                  },
                  setIcon: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  setPopup: {
                    minArgs: 1,
                    maxArgs: 1,
                    fallbackToNoCallback: !0
                  },
                  setTitle: {
                    minArgs: 1,
                    maxArgs: 1,
                    fallbackToNoCallback: !0
                  },
                  show: {
                    minArgs: 1,
                    maxArgs: 1,
                    fallbackToNoCallback: !0
                  }
                },
                permissions: {
                  contains: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getAll: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  remove: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  request: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                },
                runtime: {
                  getBackgroundPage: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  getPlatformInfo: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  openOptionsPage: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  requestUpdateCheck: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  sendMessage: {
                    minArgs: 1,
                    maxArgs: 3
                  },
                  sendNativeMessage: {
                    minArgs: 2,
                    maxArgs: 2
                  },
                  setUninstallURL: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                },
                sessions: {
                  getDevices: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  getRecentlyClosed: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  restore: {
                    minArgs: 0,
                    maxArgs: 1
                  }
                },
                storage: {
                  local: {
                    clear: {
                      minArgs: 0,
                      maxArgs: 0
                    },
                    get: {
                      minArgs: 0,
                      maxArgs: 1
                    },
                    getBytesInUse: {
                      minArgs: 0,
                      maxArgs: 1
                    },
                    remove: {
                      minArgs: 1,
                      maxArgs: 1
                    },
                    set: {
                      minArgs: 1,
                      maxArgs: 1
                    }
                  },
                  managed: {
                    get: {
                      minArgs: 0,
                      maxArgs: 1
                    },
                    getBytesInUse: {
                      minArgs: 0,
                      maxArgs: 1
                    }
                  },
                  sync: {
                    clear: {
                      minArgs: 0,
                      maxArgs: 0
                    },
                    get: {
                      minArgs: 0,
                      maxArgs: 1
                    },
                    getBytesInUse: {
                      minArgs: 0,
                      maxArgs: 1
                    },
                    remove: {
                      minArgs: 1,
                      maxArgs: 1
                    },
                    set: {
                      minArgs: 1,
                      maxArgs: 1
                    }
                  }
                },
                tabs: {
                  captureVisibleTab: {
                    minArgs: 0,
                    maxArgs: 2
                  },
                  create: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  detectLanguage: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  discard: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  duplicate: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  executeScript: {
                    minArgs: 1,
                    maxArgs: 2
                  },
                  get: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getCurrent: {
                    minArgs: 0,
                    maxArgs: 0
                  },
                  getZoom: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  getZoomSettings: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  goBack: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  goForward: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  highlight: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  insertCSS: {
                    minArgs: 1,
                    maxArgs: 2
                  },
                  move: {
                    minArgs: 2,
                    maxArgs: 2
                  },
                  query: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  reload: {
                    minArgs: 0,
                    maxArgs: 2
                  },
                  remove: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  removeCSS: {
                    minArgs: 1,
                    maxArgs: 2
                  },
                  sendMessage: {
                    minArgs: 2,
                    maxArgs: 3
                  },
                  setZoom: {
                    minArgs: 1,
                    maxArgs: 2
                  },
                  setZoomSettings: {
                    minArgs: 1,
                    maxArgs: 2
                  },
                  update: {
                    minArgs: 1,
                    maxArgs: 2
                  }
                },
                topSites: {
                  get: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                },
                webNavigation: {
                  getAllFrames: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  getFrame: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                },
                webRequest: {
                  handlerBehaviorChanged: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                },
                windows: {
                  create: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  get: {
                    minArgs: 1,
                    maxArgs: 2
                  },
                  getAll: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  getCurrent: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  getLastFocused: {
                    minArgs: 0,
                    maxArgs: 1
                  },
                  remove: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  update: {
                    minArgs: 2,
                    maxArgs: 2
                  }
                }
              };
              if (Object.keys(S).length === 0)
                throw new Error("api-metadata.json has not been included in browser-polyfill");
              class A extends WeakMap {
                constructor(g, f = void 0) {
                  super(f),
                    this.createItem = g
                }
                get(g) {
                  return this.has(g) || this.set(g, this.createItem(g)),
                    super.get(g)
                }
              }
              const v = u => u && typeof u == "object" && typeof u.then == "function"
                , k = (u, g) => (...f) => {
                  x.runtime.lastError ? u.reject(new Error(x.runtime.lastError.message)) : g.singleCallbackArg || f.length <= 1 && g.singleCallbackArg !== !1 ? u.resolve(f[0]) : u.resolve(f)
                }
                , V = u => u == 1 ? "argument" : "arguments"
                , D = (u, g) => function (b, ...P) {
                  if (P.length < g.minArgs)
                    throw new Error(`Expected at least ${g.minArgs} ${V(g.minArgs)} for ${u}(), got ${P.length}`);
                  if (P.length > g.maxArgs)
                    throw new Error(`Expected at most ${g.maxArgs} ${V(g.maxArgs)} for ${u}(), got ${P.length}`);
                  return new Promise((C, q) => {
                    if (g.fallbackToNoCallback)
                      try {
                        b[u](...P, k({
                          resolve: C,
                          reject: q
                        }, g))
                      } catch (p) {
                        console.warn(`${u} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, p),
                          b[u](...P),
                          g.fallbackToNoCallback = !1,
                          g.noCallback = !0,
                          C()
                      }
                    else
                      g.noCallback ? (b[u](...P),
                        C()) : b[u](...P, k({
                          resolve: C,
                          reject: q
                        }, g))
                  }
                  )
                }
                , W = (u, g, f) => new Proxy(g, {
                  apply(b, P, C) {
                    return f.call(P, u, ...C)
                  }
                });
              let a = Function.call.bind(Object.prototype.hasOwnProperty);
              const o = (u, g = {}, f = {}) => {
                let b = Object.create(null)
                  , P = {
                    has(q, p) {
                      return p in u || p in b
                    },
                    get(q, p, U) {
                      if (p in b)
                        return b[p];
                      if (!(p in u))
                        return;
                      let _ = u[p];
                      if (typeof _ == "function")
                        if (typeof g[p] == "function")
                          _ = W(u, u[p], g[p]);
                        else if (a(f, p)) {
                          let K = D(p, f[p]);
                          _ = W(u, u[p], K)
                        } else
                          _ = _.bind(u);
                      else if (typeof _ == "object" && _ !== null && (a(g, p) || a(f, p)))
                        _ = o(_, g[p], f[p]);
                      else if (a(f, "*"))
                        _ = o(_, g[p], f["*"]);
                      else
                        return Object.defineProperty(b, p, {
                          configurable: !0,
                          enumerable: !0,
                          get() {
                            return u[p]
                          },
                          set(K) {
                            u[p] = K
                          }
                        }),
                          _;
                      return b[p] = _,
                        _
                    },
                    set(q, p, U, _) {
                      return p in b ? b[p] = U : u[p] = U,
                        !0
                    },
                    defineProperty(q, p, U) {
                      return Reflect.defineProperty(b, p, U)
                    },
                    deleteProperty(q, p) {
                      return Reflect.deleteProperty(b, p)
                    }
                  }
                  , C = Object.create(u);
                return new Proxy(C, P)
              }
                , i = u => ({
                  addListener(g, f, ...b) {
                    g.addListener(u.get(f), ...b)
                  },
                  hasListener(g, f) {
                    return g.hasListener(u.get(f))
                  },
                  removeListener(g, f) {
                    g.removeListener(u.get(f))
                  }
                })
                , l = new A(u => typeof u != "function" ? u : function (f) {
                  const b = o(f, {}, {
                    getContent: {
                      minArgs: 0,
                      maxArgs: 0
                    }
                  });
                  u(b)
                }
                )
                , m = new A(u => typeof u != "function" ? u : function (f, b, P) {
                  let C = !1, q, p = new Promise(J => {
                    q = function (B) {
                      C = !0,
                        J(B)
                    }
                  }
                  ), U;
                  try {
                    U = u(f, b, q)
                  } catch (J) {
                    U = Promise.reject(J)
                  }
                  const _ = U !== !0 && v(U);
                  if (U !== !0 && !_ && !C)
                    return !1;
                  const K = J => {
                    J.then(B => {
                      P(B)
                    }
                      , B => {
                        let n;
                        B && (B instanceof Error || typeof B.message == "string") ? n = B.message : n = "An unexpected error occurred",
                          P({
                            __mozWebExtensionPolyfillReject__: !0,
                            message: n
                          })
                      }
                    ).catch(B => {
                      console.error("Failed to send onMessage rejected reply", B)
                    }
                    )
                  }
                    ;
                  return K(_ ? U : p),
                    !0
                }
                )
                , y = ({ reject: u, resolve: g }, f) => {
                  x.runtime.lastError ? x.runtime.lastError.message === d ? g() : u(new Error(x.runtime.lastError.message)) : f && f.__mozWebExtensionPolyfillReject__ ? u(new Error(f.message)) : g(f)
                }
                , M = (u, g, f, ...b) => {
                  if (b.length < g.minArgs)
                    throw new Error(`Expected at least ${g.minArgs} ${V(g.minArgs)} for ${u}(), got ${b.length}`);
                  if (b.length > g.maxArgs)
                    throw new Error(`Expected at most ${g.maxArgs} ${V(g.maxArgs)} for ${u}(), got ${b.length}`);
                  return new Promise((P, C) => {
                    const q = y.bind(null, {
                      resolve: P,
                      reject: C
                    });
                    b.push(q),
                      f.sendMessage(...b)
                  }
                  )
                }
                , O = {
                  devtools: {
                    network: {
                      onRequestFinished: i(l)
                    }
                  },
                  runtime: {
                    onMessage: i(m),
                    onMessageExternal: i(m),
                    sendMessage: M.bind(null, "sendMessage", {
                      minArgs: 1,
                      maxArgs: 3
                    })
                  },
                  tabs: {
                    sendMessage: M.bind(null, "sendMessage", {
                      minArgs: 2,
                      maxArgs: 3
                    })
                  }
                }
                , F = {
                  clear: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  get: {
                    minArgs: 1,
                    maxArgs: 1
                  },
                  set: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                };
              return S.privacy = {
                network: {
                  "*": F
                },
                services: {
                  "*": F
                },
                websites: {
                  "*": F
                }
              },
                o(x, O, S)
            }
            ;
          t.exports = w(chrome)
        } else
          t.exports = globalThis.browser
      })
    }
    )(Z)),
    Z.exports
}
var lr = ar();
const Q = _e(lr);
function cr(e) {
  return or(Ae(he({}, e), {
    sendMessage(r, t) {
      if (t == null)
        return Q.runtime.sendMessage(r);
      const s = typeof t == "number" ? {
        tabId: t
      } : t;
      return Q.tabs.sendMessage(s.tabId, r, s.frameId != null ? {
        frameId: s.frameId
      } : void 0)
    },
    addRootListener(r) {
      const t = (s, h) => r(typeof s == "object" ? Ae(he({}, s), {
        sender: h
      }) : s);
      return Q.runtime.onMessage.addListener(t),
        () => Q.runtime.onMessage.removeListener(t)
    }
  }))
}
const { sendMessage: Se, onMessage: yr } = cr();
function Ie() {
  return (location == null ? void 0 : location.protocol) === "chrome-extension:"
}
async function pr() {
  return chrome.tabs.query({
    active: !0,
    currentWindow: !0
  }).then(([e]) => e ? Promise.resolve(e) : Promise.reject("当前标签获取失败"))
}
async function wr(e, r = []) {
  var t;
  if (Ie()) {
    const s = await chrome.scripting.executeScript({
      target: {
        tabId: te.getState().tabId
      },
      world: "MAIN",
      func: e,
      args: r
    });
    return (t = s == null ? void 0 : s[0]) == null ? void 0 : t.result
  } else
    return Se("executeScript", {
      script: e.toString(),
      args: r
    })
}
async function vr(e) {
  return Ie() ? fetch(e).then(r => r.url) : Se("fetch", {
    url: e,
    dataType: "url"
  })
}
const xr = xe.defineItem("local:deviceId", {
  init: () => crypto.randomUUID().replace(/-/g, "")
});
function br() { }
export { G as R, Fe as a, Ve as b, gr as c, xr as d, Se as e, _e as f, De as g, pr as h, br as i, te as j, wr as k, fr as l, mr as m, Ie as n, yr as o, hr as p, vr as q, Ee as r, xe as s, We as t, Ar as u, dr as v, be as w, re as x };
